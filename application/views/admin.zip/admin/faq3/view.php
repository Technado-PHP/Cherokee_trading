<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">View Inquiry</h3>
          </div>
          <div class="tddts" style="padding-left: 20px;">
            <a href="<?php echo site_url('admin/faq3');?>" class="add-btn">Go Back</a>
          </div>             
          <div class="col-md-12">
            <div class="box-body">
             <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Faq</th>
                  <th scope="col">Details</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">Faq Heading</th>
                  <td><?php echo $record->faq_three_heading;?></td>
                </tr>
                <tr>
                  <th scope="row">Faq Text</th>
                  <td><?php echo $record->faq_three_text;?></td>
                </tr>
              </tbody>
            </table>
          </div>      
        </div>
      </div>   
    </div>
  </div>
</section>
</div>
