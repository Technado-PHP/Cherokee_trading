<script>
  $(document).ready(function (){

    $("form").on("change","#product_name",function() {    
      var str = $(this).val();
      str = str.trim().replace(/\s+/g, '-').toLowerCase();
      $('#product_slug').val(str);
    });

  });
</script>
<div class="content-wrapper">
  <section class="content-header">
    <h1>
      Product Edit
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/inventory/edit/').$record->inventory_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Supplier</label>
                  <select class="form-control" id="supplier_id" name="supplier_id" data-validation="required">
                    <?php $category = get_list('supplier');?>
                    <option value="<?php echo $record->supplier_id;?>"><?php echo get_name_by_id('supplier',$record->supplier_id);?></option>
                    <?php if(!empty($category)): foreach($category as $cat):?>
                      <option value="<?php echo $cat->supplier_id;?>"><?php echo $cat->supplier_name;?></option>
                    <?php endforeach; endif;?>
                  </select>         
                </div>

                <div class="form-group">
                  <label>Product</label>
                  <select class="form-control" id="product_id" name="product_id" data-validation="required">
                    <?php $product = get_list('product');?>
                    <option value="<?php echo $record->product_id;?>"><?php echo get_name_by_id('product',$record->product_id);?></option>
                    <?php if(!empty($product)): foreach($product as $pro):?>
                      <option value="<?php echo $pro->product_id;?>"><?php echo $pro->product_name;?></option>
                    <?php endforeach; endif;?>
                  </select>         
                </div>

                <div class="form-group">
                  <label>Batch Number</label>
                  <input type="text" class="form-control" rows="3" id="inventory_bacth_no" value="<?php echo !empty($record->inventory_bacth_no)?$record->inventory_bacth_no:''?>" name="inventory_bacth_no" required/>
                  <?php echo form_error('inventory_bacth_no'); ?>
                </div>

                 <div class="form-group">
                  <label>Expiry Date </label>
                  <input type="date" class="form-control" rows="3" id="inventory_expiry" value="<?php echo !empty($record->inventory_expiry)?$record->inventory_expiry:''?>" name="inventory_expiry" required/>
                  <?php echo form_error('inventory_expiry'); ?>
                </div>

                 <div class="form-group">
                  <label>Quantity</label>
                  <input type="text" class="form-control" rows="3" id="inventory_qty" value="<?php echo !empty($record->inventory_qty)?$record->inventory_qty:''?>" name="inventory_qty" required/>
                  <?php echo form_error('inventory_qty'); ?>
                </div>

                  <div class="form-group">
                  <label>Cost Price </label>
                  <input type="text" class="form-control" rows="3" id="inventory_cost_price" value="<?php echo !empty($record->inventory_cost_price)?$record->inventory_cost_price:''?>" name="inventory_cost_price" required/>
                  <?php echo form_error('inventory_cost_price'); ?>
                </div>


              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
