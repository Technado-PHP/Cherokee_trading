<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/faq1/edit/').$record->faq_one_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Faq Heading</label>
                  <input type="text" class="form-control" id="faq_one_heading" value="<?php echo !empty($record->faq_one_heading)?$record->faq_one_heading:''?>" name="faq_one_heading" />
                  <?php echo form_error('faq_one_heading'); ?>
                </div>

<!--                 <div class="form-group">
                  <label>faq_one Sub Heading</label>
                  <input type="text" class="form-control" id="faq_one_sub_heading" value="<?php //echo !empty($record->faq_one_sub_heading)?$record->faq_one_sub_heading:''?>" name="faq_one_sub_heading" />
                  <?php //echo form_error('faq_one_sub_heading'); ?>
                </div>

                <div class="form-group">
                  <label>faq_one Short Description</label>
                  <textarea class="form-control" rows="3" id="faq_one_short_description" name="faq_one_short_description"><?php //echo !empty($record->faq_one_short_description)?$record->faq_one_short_description:''?></textarea>
                  <?php //echo form_error('faq_one_short_description'); ?>
                </div> -->

                <div class="form-group">
                  <label>Faq Text</label>
                  <textarea class="editor form-control" rows="3" id="faq_one_text" name="faq_one_text"><?php echo !empty($record->faq_one_text)?$record->faq_one_text:''?></textarea>
                  <?php echo form_error('faq_one_text'); ?>
                </div>

<!--                 <div class="form-group">
                  <label>faq_one Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php //echo !empty($record->faq_one_image)?base_url('uploads/faq_one/').$record->faq_one_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="300" data-height="262" id="faq_one_image" name="faq_one_image">
                        <input type="text" id="faq_one_image" name="faq_one_image" value="<?php //echo !empty($record->faq_one_image)?$record->faq_one_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php //echo form_error('faq_one_image'); ?>
                </div>  -->

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
