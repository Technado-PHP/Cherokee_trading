<script>
$(document).ready(function(){    
    $("#deal_name").on("change",function() {  
        var str = $(this).val();
        str = str.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-').toLowerCase();
        $('#deal_slug').val(str);
    });
});
</script>
<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/deal/edit/').$record->deal_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 
                 <div class="form-group">
                    <label>Deal Name</label>
                    <input type="name" class="form-control" value="<?php echo !empty($record->deal_name)?$record->deal_name:''?>" id="deal_name" name="deal_name">
                    <?php echo form_error('deal_name'); ?>
                  </div>
                  <div class="form-group">
                    <label>Deal Slug</label>
                    <input type="name" class="form-control" value="<?php echo !empty($record->deal_slug)?$record->deal_slug:''?>" id="deal_slug" name="deal_slug">
                    <?php echo form_error('deal_slug'); ?>
                  </div>
                  <div class="form-group">
                    <label>Product</label>
                    <select class="form-control" id="deal_products" name="deal_products[]" multiple>
                        <?php $arr = explode(',',$record->deal_products);if($products): foreach($products as $product): ?>
                        <option <?php echo in_array($product->product_id,$arr)?'selected':''?> value="<?php echo $product->product_id?>"><?php echo $product->product_name?></option>
                        <?php endforeach; endif;?>
                    </select>    
                    <?php echo form_error('deal_products[]'); ?>
                  </div>
                  <div class="form-group">
                    <label>Deal End Time</label>
                    <input type="datetime-local" class="form-control" value="<?php echo !empty($record->deal_end_time)?$record->deal_end_time:''?>" id="deal_end_time" name="deal_end_time">
                    <?php echo form_error('deal_end_time'); ?>
                  </div>
                  
                  <div class="form-group">
                    <label>Deal Price</label>
                    <input type="name" class="form-control" value="<?php echo !empty($record->deal_price)?$record->deal_price:''?>" id="deal_price" name="deal_price">
                    <?php echo form_error('deal_price'); ?>
                  </div>
        
                <div class="form-group">
                  <label>Deal Descripition</label>
                  <textarea class="editor form-control" rows="3" id="deal_desc" name="deal_desc" required><?php echo !empty($record->deal_desc)?$record->deal_desc:''?></textarea>
                  <?php echo form_error('deal_desc'); ?>
                </div>  
                
                
                <div class="form-group">
                  <label>Deal Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php echo !empty($record->deal_image)?base_url('uploads/deal/').$record->deal_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="750" data-height="972" id="deal_image" name="deal_image">
                        <input type="text" id="deal_image" name="deal_image" value="<?php echo !empty($record->deal_image)?$record->deal_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php echo form_error('deal_image'); ?>
                </div>  
                
              
              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
