<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/adds/edit/').$record->adds_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Add Name</label>
                  <input type="text" class="form-control" rows="3" id="adds_name" value="<?php echo !empty($record->adds_name)?$record->adds_name:''?>" name="adds_name" required/>
                  <?php echo form_error('adds_name'); ?>
                </div>
                
                <div class="form-group">
                  <label>Add Link</label>
                  <input type="text" class="form-control" rows="3" id="adds_link" value="<?php echo !empty($record->adds_link)?$record->adds_link:''?>" name="adds_link"/>
                  <?php echo form_error('adds_link'); ?>
                </div>

                <div class="form-group">
                  <label>Add Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img src="<?php echo !empty($record->adds_image)?base_url('uploads/adds/').$record->adds_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="411" data-height="601" id="adds_image" name="adds_image">
                        <input type="text" id="adds_image" name="adds_image" value="<?php echo !empty($record->adds_image)?$record->adds_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php echo form_error('adds_image'); ?>
                </div> 

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
