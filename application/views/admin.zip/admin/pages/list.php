<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border"> 
             <div class="tddts">
                <a href="<?php echo site_url('admin/pages/add');?>" class="add-btn">Add New</a>
              </div>    
            </div>  
            <div class="box-body">
              <table id="datatable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.No</th>
                  <th>Pages Name</th>
                  <!-- <th>Pages Slug</th> -->
                  <th>Pages Heading</th>
                  <th>Pages Text</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>            
                <?php $i=1; if(!empty($records)): foreach($records as $record):?>    
                <tr>
                  <?php $length = strlen($record->pages_text);
                  $wordLimit = substr($record->pages_text,0,200); ?>
                  <td><?php echo $i;?></td>
                  <!-- <td><img style="max-width:80px;" src="<?php //echo !empty($record->slider_image)?base_url('uploads/pages/').$record->slider_image:'';?>"></td> -->

                  <td><?php echo !empty($record->pages_name)?$record->pages_name:'';?></td>
                  <!-- <td><?php //echo !empty($record->pages_slug)?$record->pages_slug:'';?></td> -->
                  <td><?php echo !empty($record->pages_heading)?$record->pages_heading:'';?></td>
                  <td><?php echo !empty($length > 200)?substr($record->pages_text,0,200)."......":$record->pages_text;?></td>

                  <td>
                    <a href="<?php echo !empty($record->pages_id)?base_url('admin/pages/edit/').$record->pages_id:'';?>" title="Edit"><span class="edit_icon"><i class="fa fa-pencil" aria-hidden="true"></i></span></a>
                    <a href="<?php echo !empty($record->pages_id)?base_url('admin/pages/delete/').$record->pages_id:'';?>" title="Delete"><span class="delete_icon"><i class="fa fa-trash" aria-hidden="true"></i></span></a>
                    <a href="<?php echo !empty($record->pages_id)?base_url('admin/pages/view/').$record->pages_id:'';?>"><span class="view_icon"><i class="fa fa-eye" aria-hidden="true"></i></span></a>
                  </td>
                </tr>
                <?php $i++; endforeach;?>  
                <?php else:?>
                <tr>
                  <td>No Record Found</td>
                </tr>
                <?php endif;?>
                </tbody>
              </table>
            </div>
         </div>   
      </div>
    </div>
  </section>

</div>
