<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Faq</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/faq2/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">

                <div class="form-group">
                  <label>Faq Two Heading</label>
                  <input type="name" class="form-control" id="faq_two_heading" name="faq_two_heading" >
                  <?php echo form_error('faq_two_heading'); ?>
                </div>   

                <div class="form-group">
                  <label>Faq two Text</label>
                  <textarea class="form-control editor" id="faq_two_text" name="faq_two_text" required><?php echo !empty($record->faq_two_text) ? $record->faq_two_text : ''?></textarea>
                </div>
                <?php echo form_error("faq_two_text"); ?>

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
