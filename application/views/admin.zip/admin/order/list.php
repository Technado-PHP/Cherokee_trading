<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border"> 
            </div>  
            <div class="box-body">
              <table id="datatable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.No</th>
                  <th>Order No</th>
                  <th>Tracking No</th>
                  <th>Customer Name</th>
                  <th>Customer Phone</th>
                  <th>Order Amount</th>
                  <th>Order Status</th>
                  <th>Shipped By</th>
                  <th>Payment Type</th>
                  <th>Source</th>
                  <th>Note</th>
                  <th>Date Time</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>            
                <?php $i=1; if(!empty($records)): foreach($records as $record):?>    
                <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $record->order_no;?></td>
                  <td><?php echo !empty($record->order_tracking_no)?$record->order_tracking_no:'';?></td>
                  <td><?php echo !empty($record->order_name)?$record->order_name:'';?></td>
                  <td><?php echo !empty($record->order_phone)?$record->order_phone:'';?></td>
                  <td><?php echo !empty($record->order_total_amt)?$record->order_total_amt:'';?></td>
                  <td><?php echo !empty($record->order_current_status)?$record->order_current_status:'';?></td>
                  <td><?php echo !empty($record->order_ship)?$record->order_ship:'';?></td>
                  <td><?php echo !empty($record->order_payment_type)?$record->order_payment_type:'';?></td>
                  <td><?php echo !empty($record->order_source)?$record->order_source:'';?></td>
                  <td><?php echo !empty($record->order_notes)?$record->order_notes:'';?></td>
                  <td><?php echo !empty($record->order_created_at)?date("d-m-Y H:i:s", strtotime($record->order_created_at)):'';?></td>
                      <td>
                    <a href="<?php echo !empty($record->order_id)?base_url('admin/order/edit/').$record->order_id:'';?>"><span class="edit_icon"><i class="fa fa-pencil" aria-hidden="true"></i></span></a>
                    <a target"_blank" href="<?php echo !empty($record->order_no)?base_url('invoice/').$record->order_no:'';?>"><span class="view_icon"><i class="fa fa-eye" aria-hidden="true"></i></span></a>
                  </td>
                </tr>
                <?php $i++; endforeach;?>  
                <?php else:?>
                <tr>
                  <td>No Record Found</td>
                </tr>
                <?php endif;?>
                </tbody>
              </table>
            </div>
         </div>   
      </div>
    </div>
  </section>

</div>
