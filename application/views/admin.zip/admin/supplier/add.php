<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/supplier/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">
               <div class="form-group">
                  <label>Supplier Name</label>
                  <input type="name" class="form-control" id="supplier_name" name="supplier_name" required>
                  <?php echo form_error('supplier_name'); ?>
                </div>  
                <div class="form-group">
                  <label>Contact Person Name</label>
                  <input type="name" class="form-control" id="supplier_con_person_name" name="supplier_con_person_name">
                  <?php echo form_error('supplier_con_person_name'); ?>
                </div> 
                <div class="form-group">
                  <label>Contact Person Number</label>
                  <input type="name" class="form-control" id="supplier_con_person_no" name="supplier_con_person_no" >
                  <?php echo form_error('supplier_con_person_no'); ?>
                </div>  
                <div class="form-group">
                  <label>Supplier Source</label>
                  <input type="name" class="form-control" id="supplier_source" name="supplier_source" >
                  <?php echo form_error('supplier_source'); ?>
                </div>   

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
