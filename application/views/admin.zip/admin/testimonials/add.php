<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/testimonials/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">

                <div class="form-group">
                  <label>Testimonial Image</label>
                  <div class="input-group-btn">
                     <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php echo base_url('assets/admin/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="412" data-height="277" id="testimonials_image" name="testimonials_image">
                       <label class="btn btn-info">Upload</label>
                      </div>
                     </div>
                  </div>
                </div> 

                <div class="form-group">
                  <label>Testimonial Text</label>
                  <textarea class="form-control" rows="3" id="testimonials_text" name="testimonials_text"><?php echo !empty($record->testimonials_text)?$record->testimonials_text:''?></textarea>
                  <?php echo form_error('testimonials_text'); ?>
                </div>
<!-- 
                <div class="form-group">
                  <label>Slider Button Text</label>
                  <input type="name" class="form-control" id="slider_button_text" name="slider_button_text" >
                  <?php //echo form_error('slider_button_text'); ?>
                </div>     

                <div class="form-group">
                  <label>Slider Button Link</label>
                  <input type="name" class="form-control" id="slider_button_link" name="slider_button_link" >
                  <?php //echo form_error('slider_button_link'); ?>
                </div>   --> 

<!--                 <div class="form-group">
                  <label>Slider Image</label>
                  <div class="input-group-btn">
                     <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php //echo base_url('assets/admin/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="1920" data-height="776" id="slider_image" name="slider_image">
                       <label class="btn btn-info">Upload</label>
                      </div>
                     </div>
                  </div>
                </div>   -->

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
