<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
            <div class="box-header with-border"> 
             <div class="tddts">
                <a href="<?php echo site_url('admin/slider/add');?>" class="add-btn">Add New</a>
              </div>    
            </div>  
            <div class="box-body">
              <table id="datatable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.No</th>
                  <!-- <th>Slider Image</th> -->
                  <th>Slider Heading One</th>
                  <th>Slider Heading Two</th>
                  <th>Slider Heading Three</th>
<!--                   <th>Slider Button Text</th>
                  <th>Slider Button Link</th> -->
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>            
                <?php $i=1; if(!empty($records)): foreach($records as $record):?>    
                <tr>
                  <td><?php echo $i;?></td>
                  <!-- <td><img style="max-width:80px;" src="<?php //echo !empty($record->slider_image)?base_url('uploads/slider/').$record->slider_image:'';?>"></td> -->

                  <td><?php echo !empty($record->slider_heading_one)?$record->slider_heading_one:'';?></td>
                  <td><?php echo !empty($record->slider_heading_one)?$record->slider_heading_two:'';?></td>
                  <td><?php echo !empty($record->slider_heading_one)?$record->slider_heading_three:'';?></td>
<!--                   <td><?php //echo !empty($record->slider_button_text)?$record->slider_button_text:'';?></td>
                  <td><?php //echo !empty($record->slider_button_link)?$record->slider_button_link:'';?></td> -->

                  <td>
                    <a href="<?php echo !empty($record->slider_id)?base_url('admin/slider/edit/').$record->slider_id:'';?>" title="Edit"><span class="edit_icon"><i class="fa fa-pencil" aria-hidden="true"></i></span></a>
                    <a href="<?php echo !empty($record->slider_id)?base_url('admin/slider/delete/').$record->slider_id:'';?>" title="Delete"><span class="delete_icon"><i class="fa fa-trash" aria-hidden="true"></i></span></a>
                    <!-- <a href="<?php //echo !empty($record->slider_id)?base_url('admin/slider/view/').$record->slider_id:'';?>"><span class="view_icon"><i class="fa fa-eye" aria-hidden="true"></i></span></a> -->
                  </td>
                </tr>
                <?php $i++; endforeach;?>  
                <?php else:?>
                <tr>
                  <td>No Record Found</td>
                </tr>
                <?php endif;?>
                </tbody>
              </table>
            </div>
         </div>   
      </div>
    </div>
  </section>

</div>
