<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/slider/edit/').$record->slider_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Slider Heading One</label>
                  <input type="text" class="form-control" rows="3" id="slider_heading_one" value="<?php echo !empty($record->slider_heading_one)?$record->slider_heading_one:''?>" name="slider_heading_one" />
                  <?php echo form_error('slider_heading_one'); ?>
                </div>

                <div class="form-group">
                  <label>Slider Heading Two</label>
                  <input type="text" class="form-control" rows="3" id="slider_heading_two" value="<?php echo !empty($record->slider_heading_two)?$record->slider_heading_two:''?>" name="slider_heading_two" />
                  <?php echo form_error('slider_heading_two'); ?>
                </div>

                <div class="form-group">
                  <label>Slider Heading Three</label>
                  <input type="text" class="form-control" rows="3" id="slider_heading_three" value="<?php echo !empty($record->slider_heading_three)?$record->slider_heading_three:''?>" name="slider_heading_three" />
                  <?php echo form_error('slider_heading_three'); ?>
                </div>

<!--                 <div class="form-group">
                  <label>Slider Button Text</label>
                  <input type="text" class="form-control" rows="3" id="slider_button_text" value="<?php //echo !empty($record->slider_button_text)?$record->slider_button_text:''?>" name="slider_button_text" />
                  <?php //echo form_error('slider_button_text'); ?>
                </div>

                <div class="form-group">
                  <label>Slider Button Link</label>
                  <input type="text" class="form-control" rows="3" id="slider_button_link" value="<?php // echo !empty($record->slider_button_link)?$record->slider_button_link:''?>" name="slider_button_link" />
                  <?php //echo form_error('slider_button_link'); ?>
                </div> -->

<!--                 <div class="form-group">
                  <label>Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php //echo !empty($record->slider_image)?base_url('uploads/slider/').$record->slider_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="1920" data-height="776" id="slider_image" name="slider_image">
                        <input type="text" id="slider_image" name="slider_image" value="<?php //echo !empty($record->slider_image)?$record->slider_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php //echo form_error('slider_image'); ?>
                </div>  -->

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
