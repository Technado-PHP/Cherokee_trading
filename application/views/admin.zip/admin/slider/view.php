<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">View Inquiry</h3>
          </div>     
          <div class="col-md-12">
            <div class="box-body">
             <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Attributes</th>
                  <th scope="col">Values</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">Slider Heading One</th>
                  <td><?php echo $record->slider_heading_one;?></td>
                </tr>
                <tr>
                  <th scope="row">Slider Heading Two</th>
                  <td><?php echo $record->slider_heading_two;?></td>
                </tr>
                <tr>
                  <th scope="row">Slider Heading Three</th>
                  <td><?php echo $record->slider_heading_three;?></td>
                </tr>
<!--                 <tr>
                  <th scope="row">Slider Button Text</th>
                  <td><?php //echo $record->slider_button_text;?></td>
                </tr>
                <tr>
                  <th scope="row">Slider Button Link</th>
                  <td><?php //echo $record->slider_button_link;?></td>
                </tr> -->
  <!--                 <tr>
                    <th scope="row">Slider Image</th>
                    <td><img style="max-width:80px;" src="<?php echo base_url('uploads/slider/').$record->slider_image;?>"></td>
                  </tr> -->
              </tbody>
            </table>
          </div>      
        </div>
      </div>   
    </div>
  </div>
</section>
</div>

























