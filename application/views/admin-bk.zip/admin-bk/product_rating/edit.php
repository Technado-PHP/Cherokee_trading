<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/product_rating/edit/').$record->product_rating_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Status</label>
                  <select class="form-control" id="product_rating_aproved" name="product_rating_aproved" required>
                      <option <?php echo $record->product_rating_aproved == 'Yes'?'selected':''?> value="Yes">Yes</option>
                      <option <?php echo $record->product_rating_aproved == 'No'?'selected':''?> value="No">No</option>
                    </select>  
                  <?php echo form_error('product_rating_aproved'); ?>
                </div>

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
