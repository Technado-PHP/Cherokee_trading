<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/brand/edit/').$record->brand_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

<!--                 <div class="form-group">
                  <label>Brand Name</label>
                  <input type="text" class="form-control" rows="3" id="brand_name" value="<?php //echo !empty($record->brand_name)?$record->brand_name:''?>" name="brand_name" required/>
                  <?php //echo form_error('brand_name'); ?>
                </div> -->

                <div class="form-group">
                  <label>Brand Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img src="<?php echo !empty($record->brand_image)?base_url('uploads/brand/').$record->brand_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file"  data-width="177" data-height="75" id="brand_image" name="brand_image">
                        <input type="text" id="brand_image" name="brand_image" value="<?php echo !empty($record->brand_image)?$record->brand_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                </div> 

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
