 <aside class="main-sidebar">
  <section class="sidebar">
    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?php echo !empty($this->session->userdata('master_admin_image'))?base_url('uploads/admin/').$this->session->userdata('master_admin_image'):base_url('admin/assets/img/placeholder.png');?>" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo !empty($this->session->userdata('master_admin_name'))?$this->session->userdata('master_admin_name'):'Name';?></p>
      </div>
    </div>
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MAIN NAVIGATION</li>
      <li>
        <a href="<?php echo base_url('admin');?>">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          <!-- <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span> -->
        </a>
      </li>
      <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Settings</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url('admin/settings/general');?>"><i class="fa fa-circle-o"></i>General</a></li>
          <li><a href="<?php echo base_url('admin/social');?>"><i class="fa fa-circle-o"></i>Social</a></li>
        </ul>
      </li>
      
<!--       <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Coupon</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php// echo base_url('admin/coupon');?>"><i class="fa fa-circle-o"></i>Coupon</a></li>
        </ul>
      </li> -->
<!--       <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Out Of Stock</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php //echo base_url('admin/out_stock');?>"><i class="fa fa-circle-o"></i>Out Of Stock</a></li>
        </ul>
      </li> -->
      <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Site Content</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url('admin/home-page');?>"><i class="fa fa-circle-o"></i>Home Page</a></li>
          <li><a href="<?php echo base_url('admin/slider');?>"><i class="fa fa-circle-o"></i>Home Page Slider</a></li>
          <li><a href="<?php echo base_url('admin/testimonials');?>"><i class="fa fa-circle-o"></i>Testimonials</a></li>
          <li><a href="<?php echo base_url('admin/pages');?>"><i class="fa fa-circle-o"></i>Pages Data</a></li>
          <li><a href="<?php echo base_url('admin/blog');?>"><i class="fa fa-circle-o"></i>Blog Data</a></li>
          <li><a href="<?php echo base_url('admin/videos');?>"><i class="fa fa-circle-o"></i>Video Links</a></li>
        </ul>
      </li>
<!--       <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Sales Report</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php //echo base_url('admin/report');?>"><i class="fa fa-circle-o"></i>All Reports</a></li>
        </ul>
      </li>   -->    
       <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Orders</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url('admin/order');?>"><i class="fa fa-circle-o"></i>All Orders <span><?php echo $this->order;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_pending');?>"><i class="fa fa-circle-o"></i>Pending Orders <span><?php echo $this->order_pending;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_confirm');?>"><i class="fa fa-circle-o"></i>Confirm Orders <span><?php echo $this->order_confirm;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_process');?>"><i class="fa fa-circle-o"></i>In-process Orders <span><?php echo $this->order_process;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_dispatched');?>"><i class="fa fa-circle-o"></i>Dispatched Orders <span><?php echo $this->order_dispatched;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_delivered');?>"><i class="fa fa-circle-o"></i>Delivered Orders <span><?php echo $this->order_delivered;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_cancle');?>"><i class="fa fa-circle-o"></i>Cancle Orders <span><?php echo $this->order_cancle;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_closed');?>"><i class="fa fa-circle-o"></i>Closed Orders <span><?php echo $this->order_closed;?></span></a></li>
          <li><a href="<?php echo base_url('admin/order/order_return');?>"><i class="fa fa-circle-o"></i>Return Orders <span><?php echo $this->order_return;?></span></a></li>
        </ul>
      </li>      
      <li class="treeview">
        <a href="javascript:;">
          <i class="fa fa-user"></i>
          <span>Inventory</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url('admin/category');?>"><i class="fa fa-circle-o"></i>Category</a></li>
          <li><a href="<?php echo base_url('admin/sub_category');?>"><i class="fa fa-circle-o"></i>Sub Category</a></li>
          <li><a href="<?php echo base_url('admin/supplier');?>"><i class="fa fa-circle-o"></i>Supplier </a></li>
          <li><a href="<?php echo base_url('admin/brand');?>"><i class="fa fa-circle-o"></i>Brand </a></li>
          <li><a href="<?php echo base_url('admin/filter');?>"><i class="fa fa-circle-o"></i>Filter </a></li>
          <li><a href="<?php echo base_url('admin/attribute');?>"><i class="fa fa-circle-o"></i>Attribute</a></li>
          <li><a href="<?php echo base_url('admin/variant');?>"><i class="fa fa-circle-o"></i>Variant</a></li>
          <li><a href="<?php echo base_url('admin/product');?>"><i class="fa fa-circle-o"></i>Product</a></li>
          <li><a href="<?php echo base_url('admin/product_filter');?>"><i class="fa fa-circle-o"></i>Product Filter </a></li>
          <li><a href="<?php echo base_url('admin/product_variant');?>"><i class="fa fa-circle-o"></i>Product Variant</a></li>
          <li><a href="<?php echo base_url('admin/inventory');?>"><i class="fa fa-circle-o"></i>Inventory</a></li>
          <li><a href="<?php echo base_url('admin/deal');?>"><i class="fa fa-circle-o"></i>Deals</a></li>
        </ul>
      </li>      
      <li>
        <a href="<?php echo base_url('admin/newsletter');?>">
          <i class="fa fa-dashboard"></i> <span>Newsletter</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>     
      <li>
        <a href="<?php echo base_url('admin/product_rating');?>">
          <i class="fa fa-dashboard"></i> <span>Product Reviews</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>
    </ul>
  </section>
</aside>
<?php if(isset($output)):?>
  <div class="content-wrapper">    
    <?php echo $output;?>
  </div>
<?php endif;?>