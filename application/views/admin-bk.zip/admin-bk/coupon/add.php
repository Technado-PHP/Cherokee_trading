<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/coupon/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">

               <div class="form-group">
                  <label>Coupon Code</label>
                  <input type="name" class="form-control" id="coupon_code" name="coupon_code" required>
                  <?php echo form_error('coupon_code'); ?>
                </div>
               <div class="form-group">
                  <label>Coupon Value</label>
                  <input type="number" class="form-control" id="coupon_value" name="coupon_value" required>
                  <?php echo form_error('coupon_value'); ?>
                </div>
                <div class="form-group">
                  <label>Coupon Type</label>
                  <select class="form-control" id="coupon_type" name="coupon_type" required>
                      <option value="Percentage">Percentage</option>
                      <option value="Amount">Amount</option>
                    </select>  
                  <?php echo form_error('coupon_type'); ?>
                </div> 
                
                <div class="form-group">
                  <label>Products</label>
                  <select class="form-control" id="product_id" name="product_id[]" multiple>
                      <?php if($products): foreach($products as $product):?>
                      <option value="<?php echo $product->product_id?>"><?php echo $product->product_name?></option>
                      <?php endforeach;endif;?>
                  </select>  
                  <?php echo form_error('coupon_type'); ?>
                </div> 

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
