<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/product_filter/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">
                <div class="form-group">
                    <label>Product</label>
                    <select class="form-control" id="product_id" name="product_id">
                      <option selected value="">Please Select</option>
                      <?php if(!empty($products)): foreach($products as $product):?>
                       <option value="<?php echo $product->product_id;?>"><?php echo $product->product_name;?></option>
                     <?php endforeach; endif;?>
                   </select>    
                   <?php echo form_error('product_id'); ?>      
                </div>  
                <div class="form-group">
                    <label>Filter</label>
                    <select class="form-control" id="filter_id" name="filter_id">
                      <option selected value="">Please Select</option>
                      <?php if(!empty($filters)): foreach($filters as $filter):?>
                       <option value="<?php echo $filter->filter_id;?>"><?php echo $filter->filter_name;?></option>
                     <?php endforeach; endif;?>
                   </select>    
                   <?php echo form_error('filter_id'); ?>      
                </div>   
              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
