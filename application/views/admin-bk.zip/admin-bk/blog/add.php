<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/blog/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">

                <div class="form-group">
                  <label>Blog Heading</label>
                  <input type="name" class="form-control" id="blog_heading" name="blog_heading" >
                  <?php echo form_error('blog_heading'); ?>
                </div>   

                <div class="form-group">
                  <label>Blog Sub Heading</label>
                  <input type="name" class="form-control" id="blog_sub_heading" name="blog_sub_heading" >
                  <?php echo form_error('blog_sub_heading'); ?>
                </div>   

                <div class="form-group">
                  <label>Blog Short Description</label>
                  <textarea class="form-control" id="pages_text" name="blog_short_description" required><?php echo !empty($record->blog_short_description) ? $record->blog_short_description : ''?></textarea>
                </div>
                <?php echo form_error("blog_short_description"); ?>

                <div class="form-group">
                  <label>Blog Long Description</label>
                  <textarea class="form-control editor" id="blog_long_description" name="blog_long_description" required><?php echo !empty($record->blog_long_description) ? $record->blog_long_description : ''?></textarea>
                </div>
                <?php echo form_error("blog_long_description"); ?>

                <div class="form-group">
                  <label>Blog Image</label>
                  <div class="input-group-btn">
                     <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php echo base_url('assets/admin/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="300" data-height="262" id="blog_image" name="blog_image">
                       <label class="btn btn-info">Upload</label>
                      </div>
                     </div>
                  </div>
                </div>  

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
