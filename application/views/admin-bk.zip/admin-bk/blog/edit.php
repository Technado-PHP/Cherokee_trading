<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/blog/edit/').$record->blog_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Blog Heading Name</label>
                  <input type="text" class="form-control" id="blog_heading" value="<?php echo !empty($record->blog_heading)?$record->blog_heading:''?>" name="blog_heading" />
                  <?php echo form_error('blog_heading'); ?>
                </div>

                <div class="form-group">
                  <label>Blog Sub Heading</label>
                  <input type="text" class="form-control" id="blog_sub_heading" value="<?php echo !empty($record->blog_sub_heading)?$record->blog_sub_heading:''?>" name="blog_sub_heading" />
                  <?php echo form_error('blog_sub_heading'); ?>
                </div>

                <div class="form-group">
                  <label>Blog Short Description</label>
                  <textarea class="form-control" rows="3" id="blog_short_description" name="blog_short_description"><?php echo !empty($record->blog_short_description)?$record->blog_short_description:''?></textarea>
                  <?php echo form_error('blog_short_description'); ?>
                </div>

                <div class="form-group">
                  <label>Blog Long Description</label>
                  <textarea class="editor form-control" rows="3" id="blog_long_description" name="blog_long_description"><?php echo !empty($record->blog_long_description)?$record->blog_long_description:''?></textarea>
                  <?php echo form_error('blog_long_description'); ?>
                </div>

                <div class="form-group">
                  <label>Blog Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php echo !empty($record->blog_image)?base_url('uploads/blog/').$record->blog_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="300" data-height="262" id="blog_image" name="blog_image">
                        <input type="text" id="blog_image" name="blog_image" value="<?php echo !empty($record->blog_image)?$record->blog_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php echo form_error('blog_image'); ?>
                </div> 

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
