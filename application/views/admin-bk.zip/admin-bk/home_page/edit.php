<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/home_page');?>" method="post" enctype="multipart/form-data">
              <div class="box-body">
                <!--                 <div class="form-group">
                  <label>Display On Web</label>
                  <select class="form-control" id="home_page_display" name="home_page_display">
                    <option <?php// echo $record->home_page_display=='Enable'?'selected':''?> value="Enable">Enable</option>                    
                    <option <?php// echo $record->home_page_display=='Disable'?'selected':''?> value="Disable">Disable</option>                    
                  </select>    
                  <?php// echo form_error('home_page_display'); ?>      
                  </div>  -->
                <div class="form-group">
                  <label>Banner Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">
                      <img src="<?php echo !empty($record->home_page_image)?base_url('uploads/home_page/').$record->home_page_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="733" data-height="444" id="home_page_image" name="home_page_image">
                        <input type="text" id="home_page_image" name="home_page_image" value="<?php echo !empty($record->home_page_image)?$record->home_page_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <!-- <?php// echo form_error('home_page_image'); ?>                 -->
                </div>

                <div class="form-group">
                  <label>Home Page Heading One</label>
                  <input type="name" class="form-control" id="home_page_heading_one" name="home_page_heading_one" value="<?php echo !empty($record->home_page_heading_one)?$record->home_page_heading_one:''?>" required>
                  <?php echo form_error('home_page_heading_one'); ?>
                </div>

                <div class="form-group">
                  <label>Home Page Heading Two</label>
                  <input type="name" class="form-control" id="home_page_heading_two" name="home_page_heading_two" value="<?php echo !empty($record->home_page_heading_two)?$record->home_page_heading_two:''?>" required>
                  <?php echo form_error('home_page_heading_two'); ?>
                </div>

                <div class="form-group">
                  <label>Sub Heading</label>
                  <input type="name" class="form-control" id="home_page_sub_heading" name="home_page_sub_heading" value="<?php echo !empty($record->home_page_sub_heading)?$record->home_page_sub_heading:''?>" required>
                  <?php echo form_error('home_page_sub_heading'); ?>
                </div>
                
                <div class="form-group">
                  <label>Home Page Video Link</label>
                  <input type="name" class="form-control" id="home_page_video_link" name="home_page_video_link" value="<?php echo !empty($record->home_page_video_link)?$record->home_page_video_link:''?>" required>
                  <?php echo form_error('home_page_video_link'); ?>
                </div>

<!--                 <div class="form-group">
                  <label>Button Text</label>
                  <input type="name" class="form-control" id="home_page_button_text" name="home_page_button_text" value="<?php //echo !empty($record->home_page_button_text)?$record->home_page_button_text:''?>" required>
                  <?php //echo form_error('home_page_button_text'); ?>
                </div> -->

<!--                 <div class="form-group">
                  <label>Button Link</label>
                  <input type="name" class="form-control" id="home_page_button_link" name="home_page_button_link" value="<?php //echo !empty($record->home_page_button_link)?$record->home_page_button_link:''?>" required>
                  <?php //echo form_error('home_page_button_link'); ?>
                </div> -->
<!-- 
                <div class="form-group">
                  <label>Best Seller</label>
                  <div class="input-group-btn">
                    <div class="image-upload">
                      <img src="<?php //echo !empty($record->home_page_banner_bs)?base_url('uploads/home_page/').$record->home_page_banner_bs:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="870" data-height="250" id="home_page_banner_bs" name="home_page_banner_bs">
                        <input type="text" id="home_page_banner_bs" name="home_page_banner_bs" value="<?php //echo !empty($record->home_page_banner_bs)?$record->home_page_banner_bs:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php //echo form_error('home_page_banner_bs'); ?>                
                </div>
                <div class="form-group">
                  <label>New Products</label>
                  <div class="input-group-btn">
                    <div class="image-upload">
                      <img src="<?php //echo !empty($record->home_page_banner_na)?base_url('uploads/home_page/').$record->home_page_banner_na:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="870" data-height="250" id="home_page_banner_na" name="home_page_banner_na">
                        <input type="text" id="home_page_banner_na" name="home_page_banner_na" value="<?php //echo !empty($record->home_page_banner_na)?$record->home_page_banner_na:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php //echo form_error('home_page_banner_na'); ?>                
                </div> -->
              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>