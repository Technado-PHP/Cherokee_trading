<script>
  $(document).ready(function (){
        $("#pages_name").keyup(function() {
        $("#pages_slug").val($("#pages_name").val());
        var str = $(this).val();
    str = str.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-').toLowerCase();
    $('#pages_slug').val(str);
            });
  });
</script>
<div class="content-wrapper">
  <section class="content-header">
    <h1>
        <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/pages/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">

                <div class="form-group">
                  <label>Pages Name</label>
                  <input type="name" class="form-control" id="pages_name" name="pages_name" >
                  <?php echo form_error('pages_name'); ?>
                </div>   

                <div class="form-group">
                  <!-- <label>Pages <span style="color:red;">Slug</span> </label> -->
                  <input type="hidden" class="form-control" id="pages_slug" name="pages_slug" required value="<?php echo set_value('pages_slug') ?>" readonly>
                  <?php echo form_error('pages_slug'); ?>
                </div> 

                <div class="form-group">
                  <label>Pages Heading</label>
                  <input type="name" class="form-control" id="pages_heading" name="pages_heading" >
                  <?php echo form_error('pages_heading'); ?>
                </div>

                <div class="form-group">
                  <label>Pages Text</label>
                  <textarea class="form-control editor" id="pages_text" name="pages_text" required><?php echo !empty($record->pages_text) ? $record->pages_text : ''?></textarea>
                </div>
                <?php echo form_error("pages_text"); ?>
<!--                 <div class="form-group">
                  <label>Slider Button Link</label>
                  <input type="name" class="form-control" id="slider_button_link" name="slider_button_link" >
                  <?php //echo form_error('slider_button_link'); ?>
                </div>  -->

<!--                 <div class="form-group">
                  <label>Slider Image</label>
                  <div class="input-group-btn">
                     <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php //echo base_url('assets/admin/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="1920" data-height="776" id="slider_image" name="slider_image">
                       <label class="btn btn-info">Upload</label>
                      </div>
                     </div>
                  </div>
                </div>   -->

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
