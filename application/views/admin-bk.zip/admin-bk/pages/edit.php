<script>
  $(document).ready(function (){
        $("#pages_name").keyup(function() {
        $("#pages_slug").val($("#pages_name").val());
        var str = $(this).val();
    str = str.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-').toLowerCase();
    $('#pages_slug').val(str);
            });
  });
</script>
<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/pages/edit/').$record->pages_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Pages Name</label>
                  <input type="text" class="form-control" rows="3" id="pages_name" value="<?php echo !empty($record->pages_name)?$record->pages_name:''?>" name="pages_name" />
                  <?php echo form_error('pages_name'); ?>
                </div>

                <div class="form-group">
                  <!-- <label>Category Slug</label> -->
                  <input type="hidden" class="form-control" id="pages_slug" value="<?php echo !empty($record->pages_slug)?$record->pages_slug:''?>" name="pages_slug" readonly/>
                  <?php echo form_error('pages_slug'); ?>
                </div>  

                <div class="form-group">
                  <label>Pages Heading</label>
                  <input type="text" class="form-control" rows="3" id="pages_heading" value="<?php echo !empty($record->pages_heading)?$record->pages_heading:''?>" name="pages_heading" />
                  <?php echo form_error('pages_heading'); ?>
                </div>

                <div class="form-group">
                  <label>Pages Text</label>
                  <textarea class="editor form-control" rows="3" id="pages_text" name="pages_text"><?php echo !empty($record->pages_text)?$record->pages_text:''?></textarea>
                  <?php echo form_error('pages_text'); ?>
                </div>

<!--                 <div class="form-group">
                  <label>Slider Button Text</label>
                  <input type="text" class="form-control" rows="3" id="slider_button_text" value="<?php //echo !empty($record->slider_button_text)?$record->slider_button_text:''?>" name="slider_button_text" />
                  <?php //echo form_error('slider_button_text'); ?>
                </div>

                <div class="form-group">
                  <label>Slider Button Link</label>
                  <input type="text" class="form-control" rows="3" id="slider_button_link" value="<?php // echo !empty($record->slider_button_link)?$record->slider_button_link:''?>" name="slider_button_link" />
                  <?php //echo form_error('slider_button_link'); ?>
                </div> -->

<!--                 <div class="form-group">
                  <label>Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php //echo !empty($record->slider_image)?base_url('uploads/slider/').$record->slider_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="1920" data-height="776" id="slider_image" name="slider_image">
                        <input type="text" id="slider_image" name="slider_image" value="<?php //echo !empty($record->slider_image)?$record->slider_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php //echo form_error('slider_image'); ?>
                </div>  -->

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
