<script>
$(document).ready(function(){ 
    $("#product_id").on("change",function() { 
        $.ajax({
            url: "<?php echo base_url('admin/inventory/get_variant')?>",
            type: "post",
            data: {id:$(this).val()} ,
            success: function (data){
                $('.group_one').html(data);                
            },
        });
    });      
});
</script>
<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Add Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/inventory/add')?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">

                <div class="form-group">
                  <label>Supplier</label>
                  <select class="form-control" id="supplier_id" name="supplier_id">
                    <option selected value="">Please Select</option>
                    <?php $supp = get_list('supplier');?>
                    <?php if(!empty($supp)): foreach($supp as $mp):?>
                     <option value="<?php echo $mp->supplier_id;?>"><?php echo $mp->supplier_name;?></option>
                   <?php endforeach; endif;?>
                 </select>    
                 <?php echo form_error('category_id'); ?>      
               </div> 

               <div class="form-group">
                  <label>Product</label>
                  <select class="form-control" id="product_id" name="product_id">
                    <option selected value="">Please Select</option>
                    <?php $pro = get_list('product');?>
                    <?php if(!empty($pro)): foreach($pro as $pr):?>
                     <option value="<?php echo $pr->product_id;?>"><?php echo $pr->product_name;?></option>
                   <?php endforeach; endif;?>
                 </select>    
                 <?php echo form_error('product_id'); ?>      
               </div> 


  
           <div class="form-group">
            <label>Batch Number</label>
            <input type="name" class="form-control" id="inventory_bacth_no" name="inventory_bacth_no" required>
            <?php echo form_error('inventory_bacth_no'); ?>
          </div> 

          <div class="form-group">
            <label>Expiry</label>
            <input type="date" class="form-control" id="inventory_expiry" name="inventory_expiry" required>
            <?php echo form_error('inventory_expiry'); ?>
          </div> 

            <div class="group_one">
              <div class="form-group">
                <label>Quantity</label>
                <input type="name" class="form-control" id="inventory_qty" name="inventory_qty[]" required>
                <?php echo form_error('inventory_qty[]'); ?>
              </div> 

              <div class="form-group">
                <label>Price</label>
                <input type="name" class="form-control" id="inventory_cost_price" name="inventory_cost_price[]" required>
                <?php echo form_error('inventory_cost_price[]'); ?>
              </div> 
            </div>

      </div>
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>    
    </form>        
  </div>
</div>   
</div>
</div>
</section>
</div>
