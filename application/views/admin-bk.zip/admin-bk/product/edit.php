<script>
$(document).ready(function(){    
    $("#product_name").on("change",function() {  
        var str = $(this).val();
        str = str.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-').toLowerCase();
        $('#product_slug').val(str);
    });
});
</script>
<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/product/edit/').$record->product_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body"> 

                <div class="form-group">
                  <label>Category</label>
                  <select class="form-control" id="categories_id" name="categories_id[]" required multiple>
                    <?php $subcat_id = explode(',',$record->sub_category_id);?>
                    <?php if(!empty($categorys)): foreach($categorys as $cat):?>
                    <option value="<?php echo $cat->category_id.'||'.$cat->sub_category_id;?>" <?php echo in_array($cat->sub_category_id,$subcat_id)?'selected="selected"':'' ?>>
                      <?php echo $cat->category_name.' - '.$cat->sub_category_name;?>
                      </option>
                    <?php endforeach; endif;?>
                  </select>         
                </div>
                <div class="form-group">
                  <label>Brand</label>
                  <select class="form-control" id="brand_id" name="brand_id" required>
                    <?php $brand = get_list('brand');?>
                    <option value="<?php echo $record->brand_id;?>"><?php echo get_name_by_id('brand',$record->brand_id);?></option>
                    <?php if(!empty($brand)): foreach($brand as $brands):?>
                      <option value="<?php echo $brands->brand_id;?>"><?php echo $brands->brand_name;?></option>
                    <?php endforeach; endif;?>
                  </select>         
                </div>
                

                <div class="form-group">
                  <label>Product Name</label>
                  <input type="text" class="form-control" rows="3" id="product_name" value="<?php echo !empty($record->product_name)?$record->product_name:''?>" name="product_name" required/>
                  <?php echo form_error('product_name'); ?>
                </div>

                <div class="form-group">
                  <label>Product Slug</label>
                  <input type="text" class="form-control" rows="3" id="product_slug" value="<?php echo !empty($record->product_slug)?$record->product_slug:''?>" name="product_slug" required/>
                  <?php echo form_error('product_slug'); ?>
                </div>

                <div class="form-group">
                  <label>Product SKU</label>
                  <input type="text" class="form-control" rows="3" id="product_sku" value="<?php echo !empty($record->product_sku)?$record->product_sku:''?>" name="product_sku" required/>
                  <?php echo form_error('product_sku'); ?>
                </div>

                 <div class="form-group">
                  <label>Product Regular Price</label>
                  <input type="text" class="form-control" rows="3" id="product_reg_price" value="<?php echo !empty($record->product_reg_price)?$record->product_reg_price:''?>" name="product_reg_price" required/>
                  <?php echo form_error('product_reg_price'); ?>
                </div>

                 <div class="form-group">
                  <label>Product Discounted Price</label>
                  <input type="text" class="form-control" rows="3" id="product_dis_price" value="<?php echo !empty($record->product_dis_price)?$record->product_dis_price:''?>" name="product_dis_price" required/>
                  <?php echo form_error('product_dis_price'); ?>
                </div>

                <div class="form-group">
                  <label>Product Short Descripition</label>
                  <textarea class="editor form-control" rows="3" id="product_short_desc" name="product_short_desc"><?php echo !empty($record->product_short_desc)?$record->product_short_desc:''?></textarea>
                  <?php echo form_error('product_short_desc'); ?>
                </div>

                <div class="form-group">
                  <label>Product Long Descripition</label>
                  <textarea class="editor form-control" rows="3" id="product_long_desc" name="product_long_desc"><?php echo !empty($record->product_long_desc)?$record->product_long_desc:''?></textarea>
                  <?php echo form_error('product_long_desc'); ?>
                </div>

                <div class="form-group">
                  <label>Product How To Use</label>
                  <textarea class="editor form-control" rows="3" id="product_desc_one" name="product_desc_one"><?php echo !empty($record->product_desc_one)?$record->product_desc_one:''?></textarea>
                  <?php echo form_error('product_desc_one'); ?>
                </div>

                <div class="form-group">
                  <label>Product Precautions</label>
                  <textarea class="editor form-control" rows="3" id="product_desc_two" name="product_desc_two"><?php echo !empty($record->product_desc_two)?$record->product_desc_two:''?></textarea>
                  <?php echo form_error('product_desc_two'); ?>
                </div>

                <div class="form-group">
                  <label>Image</label>
                  <div class="input-group-btn">
                    <div class="image-upload">                      
                      <img style="max-width:80px;" src="<?php echo !empty($record->product_image)?base_url('uploads/product/').$record->product_image:base_url('assets/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="750" data-height="972" id="product_image" name="product_image">
                        <input type="text" id="product_image" name="product_image" value="<?php echo !empty($record->product_image)?$record->product_image:''?>" hidden>
                        <label class="btn btn-info">Upload</label>
                      </div>
                    </div>
                  </div>
                  <?php echo form_error('product_image'); ?>
                </div>  
                
                <div class="form-group">
                  <label>Product Images</label>
                  <div class="input-group-btn">
                  <?php if(!empty($images)): foreach($images as $img):?>

                    <div class="multi-image-upload">   
                      <i class="fa fa-times" aria-hidden="true"></i>                        
                      <img style="max-width:80px;" src="<?php echo !empty($img->product_img_image)?base_url('uploads/product_img/').$img->product_img_image:base_url('assets/admin/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="text" id="product_img_image" name="product_img_image[]" value="<?php echo !empty($img->product_img_image)?$img->product_img_image:''?>" hidden>
                      </div>
                    </div>
                  <?php endforeach; endif;?>                  
                     <div class="multi-image-upload">                      
                      <img src="<?php echo base_url('assets/admin/img/placeholder.png')?>">
                      <div class="file-btn">
                        <input type="file" data-width="750" data-height="972" id="product_img_image" name="product_img_image[]">
                       <label class="btn btn-info">Upload</label>
                      </div>
                     </div>
                  </div>
                </div>  

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>

<script>
$(document).ready(function(){  
    $("#product_reg_price").keyup(function() { 
        if(+$(this).val() <= +$('#product_dis_price').val()){
            $(this).val(0);
            $(this).parent('.form-group').addClass('has-error');
            $(this).parent('.form-group').not(":has(span)").append('<span class="help-block">Regular Price can not be less than Discounted Price</span>');
            
        }
    });
    
     $("#product_dis_price").keyup(function() { 
        if(+$(this).val() >= +$('#product_reg_price').val()){
            $(this).val(0);
            $(this).parent('.form-group').addClass('has-error');
            $(this).parent('.form-group').not(":has(span)").append('<span class="help-block">Regular Price can not be less than Discounted Price</span>');
            
        }
    });
});
</script>
