<div class="content-wrapper">
  <section class="content-header">
    <h1>
      <?php echo !empty($title)?$title:'Title';?>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Edit Data</h3>
          </div>     
          <div class="col-md-6">
            <form role="form" action="<?php echo base_url('admin/order/edit/').$record->order_id;?>" method="post" enctype="multipart/form-data">       
              <div class="box-body">
               
                <div class="form-group">
                  <label>Order Status</label>
                  <select class="form-control" id="order_current_status" name="order_current_status" required>
                    <option <?php echo $record->order_current_status=='Pending'?'selected':''?> value="Pending">Pending</option>
                    <option <?php echo $record->order_current_status=='Confirm'?'selected':''?> value="Confirm">Confirm</option>
                    <option <?php echo $record->order_current_status=='In-process'?'selected':''?> value="In-process">In-process</option>
                    <option <?php echo $record->order_current_status=='Dispatched'?'selected':''?> value="Dispatched">Dispatched</option>
                    <option <?php echo $record->order_current_status=='Delivered'?'selected':''?> value="Delivered">Delivered</option>
                    <option <?php echo $record->order_current_status=='Cancle'?'selected':''?> value="Cancle">Cancle</option>
                    <option <?php echo $record->order_current_status=='Closed'?'selected':''?> value="Closed">Closed</option>
                    <option <?php echo $record->order_current_status=='Return'?'selected':''?> value="Return">Return</option>
                    
                 </select>    
                 <?php echo form_error('order_current_status'); ?>      
               </div> 

                <div class="form-group">
                  <label>Shipped By</label>
                  <select class="form-control" id="order_ship" name="order_ship">
                    <option <?php echo $record->order_current_status=='M&P Courier'?'selected':''?> value="M&P Courier">M&P Courier</option>
                    <option <?php echo $record->order_current_status=='Bykea Courier'?'selected':''?> value="Bykea Courier">Bykea Courier</option>
                    <option <?php echo $record->order_current_status=='Self Courier'?'selected':''?> value="Self Courier">Self Courier</option>
                    <option <?php echo $record->order_current_status=='Courier 4'?'selected':''?> value="Courier 4">Courie 4</option>
                    <option <?php echo $record->order_current_status=='Courier 5'?'selected':''?> value="Courier 5">Courie 5</option>
                    <option <?php echo $record->order_current_status=='Courier 6'?'selected':''?> value="Courier 6">Courie 6</option>
                    
                 </select>    
                 <?php echo form_error('order_current_status'); ?>      
               </div> 

              <div class="form-group">
                  <label>Payment Type</label>
                  <select class="form-control" id="order_payment_type" name="order_payment_type">
                    <option <?php echo $record->order_payment_type=='COD'?'selected':''?> value="COD">COD</option>
                    <option <?php echo $record->order_payment_type=='Bank Transfer'?'selected':''?> value="Bank Transfer">Bank Transfer</option>
                    <option <?php echo $record->order_payment_type=='Easy Paisa'?'selected':''?> value="Easy Paisa">Easy Paisa</option> 
                    <option <?php echo $record->order_payment_type=='Self Cash'?'selected':''?> value="Self Cash">Self Cash</option>
                    
                 </select>    
                 <?php echo form_error('order_payment_type'); ?>      
               </div> 

                <div class="form-group">
                  <label>Tracking No</label>
                  <input type="text" class="form-control" rows="3" id="order_tracking_no" value="<?php echo !empty($record->order_tracking_no)?$record->order_tracking_no:''?>" name="order_tracking_no"/>
                  <?php echo form_error('order_tracking_no'); ?>
                </div>
                
                <div class="form-group">
                  <label>Source</label>
                  <input type="text" class="form-control" rows="3" id="order_source" value="<?php echo !empty($record->order_source)?$record->order_source:''?>" name="order_source"/>
                  <?php echo form_error('order_source'); ?>
                </div>

                <div class="form-group">
                  <label>Notes</label>
                  <textarea class="form-control" rows="3" id="order_notes" value="" name="order_notes"/><?php echo !empty($record->order_notes)?$record->order_notes:''?></textarea>
                  <?php echo form_error('order_notes'); ?>
                </div>

                
              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>    
            </form>        
          </div>
        </div>   
      </div>
    </div>
  </section>
</div>
