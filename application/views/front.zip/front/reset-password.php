   
  
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Reset Password</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Reset Password</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END --> 

  <!-- CONTAIN START -->
  <section class="checkout-section ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8 col-md-8 ">
              <form class="main-form full" method="post" action="<?php echo current_url();?>" >
                <div class="row">
                  <div class="col-12 mb-20">
                    <div class="heading-part heading-bg">
                      <h2 class="heading">Reset Password</h2>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input-box">
                      <label for="login-pass">New Password</label>
                      <input id="login-pass" type="password" name="new_password" required placeholder="Enter your Password">
                        <?php echo form_error('new_password'); ?>
                    </div>
                  </div>
                  
                  <div class="col-12">
                    <div class="input-box">
                      <label for="login-pass">Confirm Password</label>
                      <input id="login-pass" type="password" name="cnf_password" required placeholder="Enter your Password">
                        <?php echo form_error('cnf_password'); ?>
                    </div>
                  </div>
                    <button name="submit" type="submit" class="btn-color right-side">Submit</button>                 
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
 