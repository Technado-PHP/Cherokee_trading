<?php if(!empty($slider)):?>
  <section class="">
    <div class="banner">
      <div class="main-banner">
        <?php foreach($slider as $slide):?>
        <div class="banner-1"> <img src="<?php echo base_url('uploads/slider/').$slide->slider_image;?>" alt="Stylexpo">
          <div class="banner-detail">
            <div class="container">
              <div class="row">
                <div class="col-lg-5 col-4"></div>
                <div class="col-lg-7 col-8">
                  <div class="banner-detail-inner"> 
                  <?php if(!empty($slide->slider_heading_one)):?>
                    <span class="slogan"><?php echo $slide->slider_heading_one;?></span>
                  <?php endif;?>
                  <?php if(!empty($slide->slider_heading_two)):?>
                   <h1 class="banner-title"><?php echo $slide->slider_heading_two;?></h1>
                  <?php endif;?>
                  <?php if(!empty($slide->slider_heading_three)):?>
                    <span class="offer"><?php echo $slide->slider_heading_three;?></span> 
                  <?php endif;?> 
                  </div>
                  <?php if(!empty($slide->slider_button_link) || !empty($slide->slider_button_text)):?>
                  <a class="btn btn-color" href="<?php echo $slide->slider_button_link;?>"><?php echo $slide->slider_button_text;?></a>
                  <?php endif;?>  
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach;?>
      </div>
    </div>
  </section>
<?php endif; ?> 
<?php if(!empty($homedata)): foreach($homedata as $home): ?>
    <div class="sub-banner-block ">
      <div class="">
        <div class=" center-sm">
          <div class="row m-0">
            <?php $catdata = null;?>
            <?php if(!empty($catdata)): foreach($catdata as $row): ?>
            <div class="col-md-4 mt-xs-30 p-0">
              <div class="sub-banner sub-banner1" >
                <img alt="Stylexpo" src="<?php echo base_url('uploads/category/').$row->category_image;?>">
                <div class="sub-banner-detail">
                  <div class="sub-banner-title sub-banner-title-color"><?php echo $row->category_name;?></div>
                  <a class="btn btn-color " href="<?php echo base_url('category/').$row->category_slug;?>">Shop Now!</a>
                </div>
              </div>
            </div>
          <?php endforeach;endif;?>
          </div>
        </div>
      </div>
    </div>
    <!-- SUB-BANNER END -->

    <!-- Top Categories Start-->
    <section class=" pt-70">
      <div class="top-cate-bg">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="heading-part mb-30 mb-xs-15">
                <h2 class="main_title heading"><span>TOP CATEGORIES</span></h2>
              </div>
            </div>
          </div>
          <div class="pro_cat">
            <div class="row">
              <div id="top-cat-pro" class="owl-carousel sell-pro align-center">
                <?php if(!empty($topcategory)): foreach($topcategory as $top): ?>
                <div class="item ">
                  <a href="<?php echo base_url('category/').$top->category_slug;?>">
                    <div class="item-inner">
                        <img src="<?php echo base_url('uploads/category/').$top->category_image;?>" alt="Stylexpo">
                      <div class="cate-detail">
                        <span><?php echo $top->category_name;?></span>
                      </div>
                    </div>
                  </a>
                </div>
                <?php endforeach; endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Top Categories End-->

    <!--  New arrivals Products Slider Block Start  -->
    <section class="ptb-70">
      <div class="container">
        <div class="product-listing">
          <div class="row">
            <div class="col-12">
              <div class="heading-part mb-30 mb-xs-15">
                <h2 class="main_title heading"><span>NEW ARRIVALS</span></h2>
              </div>
            </div>
          </div>
          <div class="pro_cat">
            <div class="row">
              <div class="owl-carousel pro-cat-slider ">     
              <?php if(!empty($newarrival)): for($x=0; $x < count($newarrival); $x++): ?>
                <div class="item">
                  <?php if(!empty($newarrival[$x])): ?>
                  <?php $new = $newarrival[$x];?>
                  <div class="product-item mb-30">
                    <div class="product-image"> <a href="<?php echo base_url('product/').$new->product_slug;?>"> <img src="<?php echo base_url('uploads/product/').$new->product_image;?>" alt="Stylexpo"> </a>
                      <div class="product-detail-inner">
                        <div class="detail-inner-left align-center">
                          <ul>
                              <li class="pro-cart-icon">
                                <form method="post">
                                  <button type="button" onclick="location.href = '<?php echo base_url()."product/".$new->product_slug;?>';" title="Add to Cart"><span></span>Add to Cart</button>
                                </form>
                              </li>
                              <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $new->product_id;?>"><a href="javascript:;" title="Wishlist"></a></li>
                              <li class="pro-compare-icon add_to_compare" data-id="<?php echo $new->product_id;?>"><a href="javascript:;" title="Compare"></a></li>
                            
                            </ul>
                        </div>  
                      </div>
                    </div>
                    <div class="product-item-details">
                        <div class="product-item-name"> 
                            <a href="<?php echo base_url('product/').$new->product_slug;?>">
                                <?php echo $new->product_name;?>
                            </a> 
                        </div>
                        <div class="price-box">
                            <?php if($new->product_dis_price > 0):?>
                            <span class="price">
                                <?php echo $this->currency.$new->product_dis_price;?>
                            </span> 
                            <del class="price old-price">
                                <?php echo $this->currency.$new->product_reg_price;?>
                            </del>
                            <?php else:?>
                            <span class="price">
                                <?php echo $this->currency.$new->product_reg_price;?>
                            </span>
                            <?php endif;?>
                        </div>
                    </div>
                  </div>
                  <?php endif;?>
                  <?php if(!empty($newarrival[++$x])): ?>
                  <?php $new = $newarrival[$x];?>
                  <div class="product-item mb-30">
                    <div class="product-image"> <a href="<?php echo base_url('product/').$new->product_slug;?>"> <img src="<?php echo base_url('uploads/product/').$new->product_image;?>" alt="Stylexpo"> </a>
                      <div class="product-detail-inner">
                        <div class="detail-inner-left align-center">
                          <ul>
                              <li class="pro-cart-icon">
                                <form method="post">
                                  <button type="button" onclick="location.href = '<?php echo base_url()."product/".$new->product_slug;?>';" title="Add to Cart"><span></span>Add to Cart</button>
                                </form>
                              </li>
                              <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $new->product_id;?>"><a href="javascript:;" title="Wishlist"></a></li>
                              <li class="pro-compare-icon add_to_compare" data-id="<?php echo $new->product_id;?>"><a href="javascript:;" title="Compare"></a></li>
                            
                            </ul>
                        </div>  
                      </div>
                    </div>
                    <div class="product-item-details">
                        <div class="product-item-name"> 
                            <a href="<?php echo base_url('product/').$new->product_slug;?>">
                                <?php echo $new->product_name;?>
                            </a> 
                        </div>
                        <div class="price-box">
                            <?php if($new->product_dis_price > 0):?>
                            <span class="price">
                                <?php echo $this->currency.$new->product_dis_price;?>
                            </span> 
                            <del class="price old-price">
                                <?php echo $this->currency.$new->product_reg_price;?>
                            </del>
                            <?php else:?>
                            <span class="price">
                                <?php echo $this->currency.$new->product_reg_price;?>
                            </span>
                            <?php endif;?>
                        </div>
                    </div>
                  </div>
                  <?php endif;?>
                </div>
                <?php endfor; endif; ?>    
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--  New arrivals Products Slider Block End  -->

    <!-- perellex-banner Start -->
    <?php if($home->home_page_display == 'Enable'):?>
    <section>
      <div style="background-image: url(<?php echo base_url('uploads/home_page/').$home->home_page_image?>);" class="perellex-banner">
        <div class="row">
          <div class="col-xl-8 offset-xl-2 ptb-70 client-box">
            <div class="perellex-delail align-center">
              <div class="perellex-offer"><span class="line-bottom"><?php echo $home->home_page_heading;?></span></div>
              <div class="perellex-title "><?php echo $home->home_page_sub_heading;?></div> 
              <p><?php echo $home->home_page_text;?></p>         
              <a href="<?php echo $home->home_page_button_link;?>" class="btn btn-color"><?php echo $home->home_page_button_text;?></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php endif;?>
    <!-- perellex-banner End -->

    <!-- Daily Deals Start -->
    <section class=" ptb-70">
      <div class="container">
        <div id="deals" class="daily-deals">
          <div class="row m-0">
            <div class="col-12 p-0">
              <div class="heading-part mb-30 mb-xs-15">
                <h2 class="main_title heading"><span>DAILY DEALS</span></h2>
              </div>
            </div>
          </div>
          <div class="pro_cat">
            <div class="row">
              <div id="daily_deals" class="owl-carousel ">
                <?php if(!empty($deals)): $i = 0; foreach($deals as $deal): ?>
                <?php
                    $dbdate = strtotime($deal->deal_end_time);
                    if(time() < $dbdate):
                ?>
                <div class="item">
                  <div class="product-item">
                    <div class="row ">
                      <div class="col-md-6 col-12 deals-img ">
                        <div class="product-image"> 
                          <a href="javascript:;"> 
                            <img src="<?php echo base_url('uploads/deal/').$deal->deal_image;?>"> 
                          </a>
                        </div>
                      </div>
                      <div class="col-md-6 col-12 mt-xs-30">
                        <div class="product-item-details">
                          <div class="product-item-name"> 
                            <a href="javascript:;"><?php echo $deal->deal_name;?></a> 
                          </div>
                          <div class="price-box"> 
                            <span class="price"><?php echo $this->currency.$deal->deal_price;?></span> 
                          </div>
                          <p><?php echo $deal->deal_desc;?></p>
                        </div>
                        <div class="product-detail-inner">
                          <div class="detail-inner-left">
                            <ul>
                            <li class="pro-cart-icon">
                                <form method="post">
                                  <button type="button" class="deal_cart" data-id="<?php echo $deal->deal_id;?>" title="Add to Cart"><span></span>Add to Cart</button>
                                </form>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <?php 
                            $date = str_replace('-','/',$deal->deal_end_time);
                            $time = str_replace('T',' ',$date);
                        ?>
                        <div class="item-offer-clock">
                          <ul id="countdown-clock<?php echo $i++;?>" class="countdownclock"  data-end-date="<?php echo $time;?>">
                            <li>
                              <span class="days">00</span>
                              <p class="days_ref">days</p>
                            </li>
                            <li class="seperator">:</li>
                            <li>
                              <span class="hours">00</span>
                              <p class="hours_ref">hrs</p>
                            </li>
                            <li class="seperator">:</li>
                            <li>
                              <span class="minutes">00</span>
                              <p class="minutes_ref">min</p>
                            </li>
                            <li class="seperator">:</li>
                            <li>
                              <span class="seconds">00</span>
                              <p class="seconds_ref">sec</p>
                            </li>
                          </ul>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
            
              <?php endif; endforeach;endif;?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
   <!-- Daily Deals End -->

    <!--  Site Services Features Block Start  -->
    <div class="ser-feature-block d-none d-sm-block">
      <div class="container">
        <div class="center-xs">
          <div class="row">
            <div class="col-xl-3 col-md-6 service-box">
              <div class="feature-box ">
                <div class="feature-icon feature1"></div>
                <div class="feature-detail">
                  <div class="ser-title">Free Delivery</div>
                  <div class="ser-subtitle">From Rs.6000</div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 service-box">
              <div class="feature-box">
                <div class="feature-icon feature2"></div>
                <div class="feature-detail">
                  <div class="ser-title">Support 24/7</div>
                  <div class="ser-subtitle">Online 24 hours</div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 service-box">
              <div class="feature-box ">
                <div class="feature-icon feature3"></div>
                <div class="feature-detail">
                  <div class="ser-title">Free return</div>
                  <div class="ser-subtitle">365 a day</div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 service-box">
              <div class="feature-box ">
                <div class="feature-icon feature4"></div>
                <div class="feature-detail">
                  <div class="ser-title">Big Saving</div>
                  <div class="ser-subtitle">Weekly Sales</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--  Site Services Features Block End  -->

    <!--  Special products Products Slider Block Start  -->
    <section class="ptb-70">
      <div class="container">
        <div class="product-listing">
          <div class="row">
            <div class="col-md-6 col-12">
              <div class="row">
                <div class="col-12">
                  <div class="heading-part mb-30 mb-xs-15">
                    <h2 class="main_title heading"><span>BEST SELLER</span></h2>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <div class=" sub-banner small-banner small-banner1">
                    <a href="#">
                      <img src="<?php echo base_url('uploads/home_page/').$home->home_page_banner_bs;?>" alt="Best Seller">
                    </a>
                  </div>
                </div>
              </div>
              <div class="pro_cat">
                <div class="row">
                  <div class="owl-carousel best-seller-pro">      
                    <?php if(!empty($bestseller)): foreach($bestseller as $best):?>
                    <div class="item">
                      <div class="product-item">
                        <div class="product-image"> <a href="<?php echo base_url('product/').$best->product_slug;?>"> <img src="<?php echo base_url('uploads/product/').$best->product_image;?>" alt="Stylexpo"> </a>
                          <div class="product-detail-inner">
                            <div class="detail-inner-left align-center">
                              <ul>
                                  <li class="pro-cart-icon">
                                    <form method="post">
                                      <button type="button" onclick="location.href = '<?php echo base_url()."product/".$best->product_slug;?>';" title="Add to Cart"><span></span>Add to Cart</button>
                                    </form>
                                  </li>
                                  <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $best->product_id;?>"><a href="javascript:;" title="Wishlist"></a></li>
                                  <li class="pro-compare-icon add_to_compare" data-id="<?php echo $best->product_id;?>"><a href="javascript:;" title="Compare"></a></li>
                                
                                </ul>
                            </div>  
                          </div>
                        </div>
                        <div class="product-item-details">
                          <div class="product-item-name"> <a href="<?php echo base_url('product/').$best->product_slug;?>"><?php echo $best->product_name;?></a> </div>
                          
                            <div class="price-box">
                                <?php if($best->product_dis_price > 0):?>
                                <span class="price">
                                    <?php echo $this->currency.$best->product_dis_price;?>
                                </span> 
                                <del class="price old-price">
                                    <?php echo $this->currency.$best->product_reg_price;?>
                                </del>
                                <?php else:?>
                                <span class="price">
                                    <?php echo $this->currency.$best->product_reg_price;?>
                                </span>
                                <?php endif;?>
                            </div>
                        </div>
                      </div>
                    </div>
                    <?php endforeach; endif; ?>  
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-12 mt-xs-30">
              <div class="row">
                <div class="col-12">
                  <div class="heading-part mb-30 mb-xs-15">
                    <h2 class="main_title heading"><span>NEW PRODUCTS</span></h2>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <div class="sub-banner small-banner small-banner2">
                    <a href="#">
                      <img src="<?php echo base_url('uploads/home_page/').$home->home_page_banner_na;?>" alt="New Products">
                    </a>
                  </div>
                </div>
              </div>
              <div class="pro_cat">
                <div class="row">
                  <div class="owl-carousel best-seller-pro">
                    <?php $i=1; if(!empty($newpros)): foreach($newpros as $newpro): $i++; if($i > 16):?>
                    <div class="item">
                      <div class="product-item">
                        <div class="product-image"> <a href="<?php echo base_url('product/').$newpro->product_slug;?>"> <img src="<?php echo base_url('uploads/product/').$newpro->product_image;?>" alt="Stylexpo"> </a>
                          <div class="product-detail-inner">
                            <div class="detail-inner-left align-center">
                              <ul>
                                  <li class="pro-cart-icon">
                                    <form method="post">
                                      <button type="button" onclick="location.href = '<?php echo base_url()."product/".$newpro->product_slug;?>';" title="Add to Cart"><span></span>Add to Cart</button>
                                    </form>
                                  </li>
                                  <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $newpro->product_id;?>"><a href="javascript:;" title="Wishlist"></a></li>
                                  <li class="pro-compare-icon add_to_compare" data-id="<?php echo $newpro->product_id;?>"><a href="javascript:;" title="Compare"></a></li>
                                
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div class="product-item-details">
                            <div class="product-item-name">
                               <a href="<?php echo base_url('product/').$newpro->product_slug;?>">
                               <?php echo $newpro->product_name;?>
                               </a> 
                            </div>                          
                            <div class="price-box">
                                <?php if($newpro->product_dis_price > 0):?>
                                <span class="price">
                                    <?php echo $this->currency.$newpro->product_dis_price;?>
                                </span> 
                                <del class="price old-price">
                                    <?php echo $this->currency.$newpro->product_reg_price;?>
                                </del>
                                <?php else:?>
                                <span class="price">
                                    <?php echo $this->currency.$newpro->product_reg_price;?>
                                </span>
                                <?php endif;?>
                            </div>  
                        </div>
                      </div>
                    </div>
                    <?php endif; endforeach; endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--  Special products Products Slider Block End  -->
   
    <!-- Brand logo block Start  -->
    <div class="brand-logo ">
      <div class="container">
        <div class="row">
          <div class="col-12 ">
            <div class="heading-part mb-30 mb-xs-15">
              <h2 class="main_title heading"><span>OUR BRANDS</span></h2>
            </div>
          </div>
        </div>
        <div class="row brand">
          <div class="col-md-12">
            <div id="brand-logo" class="owl-carousel align_center">
              <?php if(!empty($brands)): foreach($brands as $bra): ?>
              <div class="item"><a href="javascript:"><img src="<?php echo base_url('uploads/brand/').$bra->brand_image;?>" alt="Stylexpo"></a></div>
            <?php endforeach; endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>

 <?php endforeach; endif; ?>
    <!-- Brand logo block End  -->
    <!-- CONTAINER END --> 

 