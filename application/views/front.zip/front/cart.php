   
  
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Shopping Cart</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Shopping Cart</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->
  
  <!-- CONTAIN START -->
  <?php if($this->cart->contents()): ?>  
  <section class="ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="cart-item-table commun-table">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Sub Total</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ($this->cart->contents() as $items): ?>
                  <tr>
                    <td>
                      <a href="product-page.html">
                        <div class="product-image">
                            <?php if(!empty($items['type']) && $items['type'] == 'deal'):?>
                          <img alt="Stylexpo" src="<?php echo !empty($items['image'])?base_url('uploads/deal/').$items['image']:'';?>"> 
                          <?php else:?>
                          <img alt="Stylexpo" src="<?php echo !empty($items['image'])?base_url('uploads/product/').$items['image']:'';?>">                          
                        <?php endif;?>
                        </div>
                      </a>
                    </td>
                    <td>
                      <div class="product-title"> 
                        <?php echo !empty($items['name'])?$items['name']:'';?><br/>
                        <?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
                        <strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
                        <?php endforeach; ?>
                      </div>
                    </td>
                    <td>
                      <ul>
                        <li>
                          <div class="base-price price-box"> 
                            <span class="price"><?php echo !empty($items['price'])?$this->currency.$items['price']:'';?></span> 
                          </div>
                        </li>
                      </ul>
                    </td>
                    <td>
                      <div class="input-box select-dropdown">
                        <fieldset>
                          <div class="custom-qty">
                            <button class="reduced cart items" type="button"> <i class="fa fa-minus"></i> </button>
                            <input type="text" data-id="<?php echo !empty($items['rowid'])?$items['rowid']:'';?>" data-proid="<?php echo !empty($items['id'])?$items['id']:'';?>"  class="input-text cart-qty qty" title="Qty" value="<?php echo !empty($items['qty'])?$items['qty']:'';?>" min="1" maxlength="8" id="qty-cart" name="qty" required>
                            <button class="increase cart items" type="button"> <i class="fa fa-plus"></i> </button>
                          </div>
                        </fieldset>
                      </div>
                    </td>
                    <td>
                      <div class="total-price price-box"> 
                        <span class="price"><?php echo !empty($items['subtotal'])?$this->currency.$items['subtotal']:'';?></span> 
                      </div>
                    </td>
                    <td>
                      <i title="Remove Item From Cart" data-id="<?php echo !empty($items['rowid'])?$items['rowid']:'';?>" class="fa fa-trash cart-remove-item"></i>
                    </td>
                  </tr>
                <?php endforeach;?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <div class="mb-30">
        <div class="row">
          <div class="col-md-6">
            <div class="mt-30"> 
              <a href="<?php echo base_url();?>" class="btn btn-color">
                <span><i class="fa fa-angle-left"></i></span>
                Continue Shopping
              </a> 
            </div>
          </div>
          <div class="col-md-6">
            <div class="mt-30 right-side float-none-xs"> 
              <a id="cart_update" class="btn btn-color">Update Cart</a> 
            </div>
          </div>
        </div>
      </div>
      <hr>
      
          
            
            <div class="row">
              <div class="offset-xl-6 col-xl-6 col-sm-12">
                  <div class="coupon-code">
                    <input type="text" id="coupon-code" placeholder="Enter Your Code Here" value="<?php echo !empty($this->session->userdata('coupon_code'))?$this->session->userdata('coupon_code'):''?>">
                    <a href="javascript:;" id="apply-coupon" class="btn btn-color">Validate</a>
            <p><strong>Discount codes are not applicable on Bundle Packs and Deals</strong></p>
                  </div>
                </div>
            </div>
          
            <div class="row">
                <div class="heading-part align-center">
                  <h2 class="heading">Please fill up your details</h2>
                </div>
                </div>
            <div class="row">    
              <div class="col-xl-6 col-lg-6 col-md-6">
                <form id="checkput_form" action="<?php echo base_url('checkout');?>" method="post" style="background: #f5f5f5; padding: 15px;" class="main-form full">
                  <h5 style="text-transform:capitalize;color: #666666; padding:15px 25px;">Address</h5>
                  <div class="row" style="background: #f5f5f5;">
                    <div class="col-md-6">
                        <input type="text" name="name" value="<?php echo !empty($this->session->userdata('customer_name'))?$this->session->userdata('customer_name'):'';?>" required placeholder="Full Name">
                        <?php echo form_error('name'); ?>
                    </div>
                    <div class="col-md-6">
                        <input type="email" name="email" value="<?php echo !empty($this->session->userdata('customer_email'))?$this->session->userdata('customer_email'):'';?>" placeholder="Email Address">
                        <?php echo form_error('email'); ?>
                    </div>
                    <div class="col-md-6">
                        <input type="phone" name="phone" value="<?php echo !empty($this->session->userdata('customer_phone'))?$this->session->userdata('customer_phone'):'';?>" required placeholder="Contact Number">
                        <?php echo form_error('phone'); ?>
                     </div>
                    <div class="col-md-6">
                        <input type="text" name="state" placeholder="Province">
                        <?php echo form_error('state'); ?>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="city" placeholder="City">
                        <?php echo form_error('city'); ?>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="landmark" placeholder="Nearest Land Mark">
                        <?php echo form_error('landmark'); ?>
                    </div>
                    <div class="col-md-12">
                        <textarea type="text" row="5" name="address" required placeholder="Address"><?php echo !empty($this->session->userdata('customer_address'))?$this->session->userdata('customer_address'):'';?></textarea>
                        <span>Please provide the complete Address.</span> 
                        <?php echo form_error('address'); ?>
                      </div>
                  
                  </div>
                </form>
              </div>
            
          <div class="col-md-6">
            <div class="cart-total-table commun-table">
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th colspan="2">Cart Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Item(s) Subtotal</td>
                      <td>
                        <div class="price-box"> 
                          <span class="price"><?php echo $this->currency.$this->cart->total();?></span> 
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Discount</td>
                      <td>
                        <div class="price-box"> 
                          <span class="price"><?php echo $this->currency.(cart_dis());?></span> 
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Shipping</td>
                      <td>
                        <div class="price-box"> 
                          <span class="price"><?php echo $this->currency.($this->cart->total()>6000?0:150);?></span> 
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><b>Amount Payable</b></td>
                      <td>
                        <div class="price-box"> 
                          <span class="price"><b><?php echo $this->currency.($this->cart->total()>6000-cart_dis()?$this->cart->total()-cart_dis():$this->cart->total()+150-cart_dis());?></b></span> 
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <hr>
      <div class="mt-30">
        <div class="row">
          <div class="col-12">
            <div class="right-side float-none-xs"> 
              <a href="javascript:;" onclick="$('#checkput_form').submit()" class="btn btn-color">Proceed to checkout
                <span><i class="fa fa-angle-right"></i></span>
              </a> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  

 <?php else:?>    
  <section class="ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="mb-30 mt-30">
            <h1>No Products In Cart</h1>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php endif;?>
  <!-- CONTAINER END --> 
 