<?php if(!empty($prodetails)): foreach($prodetails as $row): ?>
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title"><?php echo get_name_by_id('category',get_single_id($row->category_id))?></h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url('');?>">Home</a>/</li>
            <li><a href="<?php echo base_url('category/').$category_slug;?>"><?php echo !empty($category)?$category:''; ?></a>/</li>
            <li><span><?php echo $row->product_name?></span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <section class="pt-70">
    <div class="container">
      <div class="row">
        <div class="col-lg-9">
          <div class="row">
            <div class="col-lg-5 col-md-5 mb-xs-30">
              <div class="fotorama" data-nav="thumbs" data-allowfullscreen="native"> 

                <a href="#"><img src="<?php echo base_url('uploads/product/').$row->product_image;?>" alt="Stylexpo"></a> 

                <?php if(!empty($productimages)): foreach($productimages as $image): ?>
                <a href="#"><img src="<?php echo base_url('uploads/product_img/').$image->product_img_image;?>" alt="Stylexpo"></a> 
              <?php endforeach; endif; ?>
              </div>
            </div>
            <div class="col-lg-7 col-md-7">
              <div class="row">
                <div class="col-12">
                  <div class="product-detail-main">
                    <div class="product-item-details">
                      <h1 class="product-item-name"><?php echo $row->product_name;?></h1>
                      <!--<div class="rating-summary-block">
                        <div title="<?php echo get_rating($row->product_id)*100/5 ;?>" class="rating-result"> <span style="width:<?php echo get_rating($row->product_id)*100/5 ;?>"></span> </div>
                      </div>
                      -->
                      <div class="price-box"> 
                      <span class="price fn">
                      <?php echo  $this->currency; echo $row->product_dis_price > 0? $row->product_dis_price:$row->product_reg_price; ?>
                      </span> 
                      <del class="price old-price">
                      <?php echo $row->product_dis_price > 0? $this->currency . $row->product_reg_price:'';?>
                      </del> 
                      </div>
                      <div class="product-info-stock-sku">
                        <div>
                          <label>Availability: </label>
                          <?php $qty = check_inventory($row->product_id);?>  
                          <?php if($qty > 0):?>
                          <span class="info-deta">In stock</span> 
                          <?php else:?>
                          <span class="info-deta">Out of stock</span>
                          <?php endif;?> 
                        </div>
                        <div>
                          <label>SKU: </label>
                          <span class="info-deta"><?php echo $row->product_sku;?></span> 
                        </div>
                      </div>
                      <p><?php echo $row->product_short_desc;?></p>
                      <?php if($qty > 0):?>                      
                      <form id="cart_submit" action="cart" method="post">
                      <input type="hidden" value="<?php echo $row->product_id;?>" name="id">
                      <input type="hidden" value="<?php echo $row->product_dis_price > 0?$row->product_dis_price:$row->product_reg_price;?>" id="actual_price">
                      <?php if(!empty($variants)): $temp=array(); foreach($variants as $var): if(!in_array($var->attribute_id,$temp)): array_push($temp,$var->attribute_id);?>
                      <div class="product-size select-arrow input-box select-dropdown mb-20 mt-30">
                        <label><?php echo $var->attribute_name;?></label>
                        <fieldset>
                          <select class="form-control atrr_var" name="attr_id-<?php echo $var->attribute_id;?>" required>                      
                                <option value="">Select</option>
                                <?php foreach($variants as $varn): if($varn->attribute_id == $var->attribute_id):?>
                                    <option value="<?php echo $varn->variant_id;?>"><?php echo $varn->variant_name;?> (+<?php echo $varn->product_variant_price;?>)</option>
                                <?php endif; endforeach;?>                                
                          </select>
                        </fieldset>
                      </div>
                      <?php endif; endforeach; endif;?>
                      <div class="mb-20">
                        <div class="product-qty">
                          <label for="qty">Qty:</label>
                          <div class="custom-qty">
                            <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) result.value--;return false;" class="reduced items" type="button"> <i class="fa fa-minus"></i> </button>
                            <input type="text" class="input-text qty" title="Qty" value="1" min="1" maxlength="8" id="qty" name="qty" required>
                            <button onclick="var result = document.getElementById('qty'); var qty = result.value; if( !isNaN( qty )) result.value++;return false;" class="increase items" type="button"> <i class="fa fa-plus"></i> </button>
                          </div>
                        </div>
                        <div class="bottom-detail cart-button">
                          <ul>
                             <a class="cart_pop popup-with-form" href="#cart_popup"></a>
                            <li class="pro-cart-icon">
                                <button title="Add to Cart" type="submit" class="btn-color "><span></span>Add to Cart</button>                              
                            </li>
                          </ul>
                        </div>
                        
                        <div class="cart_popup mt-30" style="display:none; border: 1px solid; padding: 15px;text-align: center;">
                            <h3 style="font-weight:800">Added To Cart</h3>
                            <a href="<?php echo base_url();?>" style="border-bottom:1px solid">Continue To Shop</a> <span style="margin:0 10px">OR</span>
                            <a href="<?php echo base_url('cart');?>" class="btn-color btn">Go To Cart</a>
                          </div>
                      </div>                      
                      </form>                      
                      <?php endif;?> 
                      <div class="bottom-detail">
                        <ul>
                        <?php if($qty > 0):?>                          
                          <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $row->product_id;?>"><a href="javascript:"><span></span>Wishlist</a></li>
                          <li class="pro-compare-icon"><a href="compare.html"><span></span>Compare</a></li>
                          <!--<li class="pro-email-icon"><a href="#"><span></span>Email to Friends</a></li>-->
                       <?php else:?>
                          <div class="main-form out_stock_form mt-30" style=" border: 1px solid; padding: 15px;">
                            <p><span style="color:red">Item out of stock - notify me! </span><br>Enter your phone number or email address below to be notified when this item is back in stock:</p>
                            <form action="<?php echo base_url('product/notification');?>" method="post">
                              <div class="row mt-30">
                                <div class="col-md-12 mb-30">
                                  <input type="hidden" name="product_id" value="<?php echo $row->product_id;?>">
                                  <input type="email" name="out_stock_email" placeholder="Email">
                                </div>
                                <div class="col-md-12 mb-30">
                                  <input type="text" name="out_stock_phone" placeholder="Phone" required>
                                </div>
                                <div class="col-12 mb-30">
                                  <button class="btn btn-color" name="submit" type="submit">Submit</button>
                                </div>
                              </div>
                            </form>
                          </div>
                       <?php endif;?> 
                        
                       </ul>
                      </div>
                      <!--
                      <div class="share-link">
                        <label>Share This : </label>
                        <div class="social-link">
                          <ul class="social-icon">
                            <li><a class="facebook" title="Facebook" href="#"><i class="fa fa-facebook"> </i></a></li>
                            <li><a class="twitter" title="Twitter" href="#"><i class="fa fa-twitter"> </i></a></li>
                            <li><a class="linkedin" title="Linkedin" href="#"><i class="fa fa-linkedin"> </i></a></li>
                            <li><a class="rss" title="RSS" href="#"><i class="fa fa-rss"> </i></a></li>
                            <li><a class="pinterest" title="Pinterest" href="#"><i class="fa fa-pinterest"> </i></a></li>
                          </ul>
                        </div>
                      </div>                      
                        -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="brand-logo-pro align-center mb-30">
            <a href="<?php echo !empty($this->adds->adds_link)?$this->adds->adds_link:'javascript:;';?>"> 
                <img src="<?php echo !empty($this->adds->adds_image)?base_url('uploads/adds/').$this->adds->adds_image:'';?>" alt="Stylexpo"> 
            </a> 
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ptb-70">
    <div class="container">
      <div class="product-detail-tab">
        <div class="row">
          <div class="col-lg-12">
            <div id="tabs">
              <ul class="nav nav-tabs">
                <li><a class="tab-Description selected" title="Description">Description</a></li>
                <li><a class="tab-How" title="How">How To Use</a></li> 
                <li><a class="tab-Precautions" title="Precautions">Precautions</a></li>
                <li><a class="tab-Reviews" title="Reviews">Reviews</a></li>
              </ul>
            </div>
            <div id="items">
              <div class="tab_content">
                <ul>
                  <li>
                    <div class="items-Description selected ">
                      <div class="Description"> 
                        <p><?php echo $row->product_long_desc;?></p>
                      </div> 
                    </div>
                  </li>
                  <li>
                    <div class="items-How">
                      <div class="Description"> 
                        <p><?php echo $row->product_desc_one;?></p>
                      </div> 
                    </div>
                  </li>
                  <li>
                    <div class="items-Precautions">
                      <div class="Description"> 
                        <p><?php echo $row->product_desc_two;?></p>
                      </div> 
                    </div>
                  </li>
                  <li>
                    <div class="items-Reviews">
                      <div class="comments-area">
                        <h4>Comments<span> (<?php echo count($product_rating)?>)</span></h4>
                        
                        <ul class="comment-list mt-30">
                        <?php if(!empty($product_rating)): foreach($product_rating as $rating):?>
                          <li>
                            <div class="comment-detail">
                              <div class="user-name"><?php echo $rating->product_rating_name?></div>
                              <div class="post-info">
                                <ul>
                                  <li><?php echo date_format(date_create($rating->product_rating_created_at),'m-d-Y')?></li>
                                </ul>
                              </div>
                              <p><?php echo $rating->product_rating_msg?></p>
                            </div> 
                          </li>
                          <?php endforeach;endif;?>
                        </ul>
                        
                      </div>
                      <div class="main-form mt-30">
                        <?php if(!$this->session->userdata('customer_id')):?>
                        <h4><a href="<?php echo base_url('login');?>"><strong>Login Here</strong></a> To Leave a comment</h4>
                        <?php else:?>
                        <h4>Leave a comment</h4>
                        <form action="<?php echo base_url('product/comments');?>" method="post">
                          <div class="row mt-30">
                            <div class="col-md-4 mb-30">
                              <input type="hidden" name="product_id" value="<?php echo $row->product_id;?>">
                              <input type="text" name="name" placeholder="Name" required minlength="2" maxlength="25">
                              <?php echo form_error('name'); ?>
                            </div>
                            <div class="col-md-4 mb-30">
                              <input type="email" name="email" placeholder="Email" minlength="5" maxlength="50">
                              <?php echo form_error('email'); ?>
                            </div>
                            <div class="col-md-4 mb-30">
                              <input type="phone" name="phone" placeholder="Phone" minlength="12" maxlength="12" required>
                              <?php echo form_error('phone'); ?>
                            </div>
                            <div class="col-12 mb-30">
                              <textarea cols="30" rows="3"  name="message" placeholder="Message" minlength="5" maxlength="50" required></textarea>
                              <?php echo form_error('message'); ?>
                            </div>
                            <div class="col-12 mb-30">
                              <button class="btn btn-color" name="submit" type="submit">Submit</button>
                            </div>
                          </div>
                        </form>
                        <?php endif;?>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php endforeach; endif; ?>

  <section class="pb-70">
    <div class="container">
      <div class="product-listing">
        <div class="row">
          <div class="col-12">
            <div class="heading-part mb-40">
              <h2 class="main_title heading"><span>Related Products</span></h2>
            </div>
          </div>
        </div>
        <div class="pro_cat">
          <div class="row">
            <div class="owl-carousel pro-cat-slider">
            <?php if(!empty($related)): foreach($related as $new): ?>
                <div class="item">
                  <div class="product-item mb-30">
                    <div class="product-image"> <a href="<?php echo base_url('product/').$new->product_slug;?>"> <img src="<?php echo base_url('uploads/product/').$new->product_image;?>" alt="Stylexpo"> </a>
                      <div class="product-detail-inner">
                        <div class="detail-inner-left align-center">
                          <ul>
                              <li class="pro-cart-icon">
                                <form method="post">
                                  <button type="button" onclick="location.href = '<?php echo base_url()."product/".$new->product_slug;?>';" title="Add to Cart"><span></span>Add to Cart</button>
                                </form>
                              </li>
                              <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $new->product_id;?>"><a href="javascript:;" title="Wishlist"></a></li>
                              <li class="pro-compare-icon add_to_compare" data-id="<?php echo $new->product_id;?>"><a href="javascript:;" title="Compare"></a></li>
                                                       </ul>
                        </div>  
                      </div>
                    </div>
                    <div class="product-item-details">
                        <div class="product-item-name"> 
                            <a href="<?php echo base_url('product/').$new->product_slug;?>">
                                <?php echo $new->product_name;?>
                            </a> 
                        </div>
                        <div class="price-box">
                            <?php if($new->product_dis_price > 0):?>
                            <span class="price">
                                <?php echo $this->currency.$new->product_dis_price;?>
                            </span> 
                            <del class="price old-price">
                                <?php echo $this->currency.$new->product_reg_price;?>
                            </del>
                            <?php else:?>
                            <span class="price">
                                <?php echo $this->currency.$new->product_reg_price;?>
                            </span>
                            <?php endif;?>
                        </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; endif; ?>    
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
  