  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Deals</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url('');?>">Home</a>/</li>
            <li><span>Deals</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <section>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
               <?php if(!empty($deals)): $i = 0; foreach($deals as $deal): ?>
                <?php
                    $dbdate = strtotime($deal->deal_end_time);
                    if(time() < $dbdate):
                ?>
                <div class="col-md-6">
                  <div class="product-item">
                    <div class="row pt-70">
                      <div class="col-md-6 col-12 deals-img ">
                        <div class="product-image"> 
                          <a href="javascript:;"> 
                            <img src="<?php echo base_url('uploads/deal/').$deal->deal_image;?>"> 
                          </a>
                        </div>
                      </div>
                      <div class="col-md-6 col-12 mt-xs-30">
                        <div class="product-item-details">
                          <div class="product-item-name"> 
                            <a href="javascript:;"><?php echo $deal->deal_name;?></a> 
                          </div>
                          <div class="price-box"> 
                            <span class="price"><?php echo $this->currency.$deal->deal_price;?></span> 
                          </div>
                          <p><?php echo $deal->deal_desc;?></p>
                        </div>
                        <div class="product-detail-inner">
                          <div class="detail-inner-left">
                            <ul>
                            <li class="pro-cart-icon">
                                <form method="post">
                                  <button type="button" class="deal_cart" data-id="<?php echo $deal->deal_id;?>" title="Add to Cart"><span></span>Add to Cart</button>
                                </form>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <?php 
                            $date = str_replace('-','/',$deal->deal_end_time);
                            $time = str_replace('T',' ',$date);
                        ?>
                        <div class="item-offer-clock">
                          <ul id="countdown-clock<?php echo $i++;?>" class="countdownclock"  data-end-date="<?php echo $time;?>">
                            <li>
                              <span class="days">00</span>
                              <p class="days_ref">days</p>
                            </li>
                            <li class="seperator">:</li>
                            <li>
                              <span class="hours">00</span>
                              <p class="hours_ref">hrs</p>
                            </li>
                            <li class="seperator">:</li>
                            <li>
                              <span class="minutes">00</span>
                              <p class="minutes_ref">min</p>
                            </li>
                            <li class="seperator">:</li>
                            <li>
                              <span class="seconds">00</span>
                              <p class="seconds_ref">sec</p>
                            </li>
                          </ul>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
            
              <?php endif; endforeach;endif;?>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
  