    
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">About Us</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>About Us</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->  
  
  <!-- CONTAIN START ptb-95-->
  <section class="ptb-70 align-center">
    <div class="container">
      <div class="row">
          <div class="row">
            <div class="col-8 offset-2">
              <h3>Welcome to The Skinfit!</h3>
              <p>TheSkinfit intends to offer the latest Skincare & Beauty Products to our customers. We’ve come a long way, and we know which direction to take when supplying T.S.F Family with premium quality products.</p>
              <p>We keep a close eye on the latest trends in Skincare & Beauty category and put our customers’ wishes first. For this very reason, we have satisfied customers all over the world. The interests of our customers are always the top priority for us, so we hope you will enjoy our products as much as we enjoy making them available to you.</p>
              <p>We ONLY deal in original and authentic products. Also, we are Authorized Distributor and Reseller of many International brands. So, no need to worry while shopping here for authenticity and originality of the product.</p>
            </div>
          </div>
        </div>
  </section>