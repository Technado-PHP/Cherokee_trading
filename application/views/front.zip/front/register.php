 
  
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Register</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Register</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END --> 

  <!-- CONTAIN START -->
  <section class="checkout-section ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8 col-md-8 ">
              <form class="main-form full" method="post" action="<?php echo base_url('register');?>">
                <div class="row">
                  <div class="col-12 mb-20">
                    <div class="heading-part heading-bg">
                      <h2 class="heading">Create your account</h2>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input-box">
                      <label for="f-name">Name</label>
                      <input type="text" id="name" name="name" value="<?php echo set_value('name');?>" required placeholder="Full Name">
                      <?php echo form_error('name'); ?>  
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input-box">
                      <label for="login-email">Email address</label>
                      <input id="email" type="email" name="email" value="<?php echo set_value('email');?>"  placeholder="Email Address">
                      <?php echo form_error('email'); ?>  
                    </div>
                  </div>                  
                  <div class="col-12">
                    <div class="input-box">
                      <label for="login-email">Phone Number</label>
                      <input id="phone" type="text" name="phone" value="<?php echo set_value('phone');?>"  placeholder="Phone Number">
                      <?php echo form_error('phone'); ?>  
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input-box">
                      <label for="login-pass">Password</label>
                      <input id="login-pass" type="password" name="password" value="<?php echo set_value('password');?>"  required placeholder="Enter your Password">
                      <?php echo form_error('password'); ?>  
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="input-box">
                      <label for="re-enter-pass">Re-enter Password</label>
                      <input id="re-enter-pass" type="password" name="c_password" value="<?php echo set_value('c_password');?>"  required placeholder="Re-enter your Password">
                      <?php echo form_error('c_password'); ?>  
                    </div>
                  </div>                  
                  <div class="col-12">                    
                    <button name="submit" type="submit" class="btn-color right-side">Submit</button>
                  </div>
                  <div class="col-12">
                    <hr>
                    <div class="new-account align-center mt-20"> <span>Already have an account with us</span> <a class="link" title="Register with Stylexpo" href="<?php echo base_url('login');?>">Login Here</a> </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
 