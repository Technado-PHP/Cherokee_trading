<?php if(!empty($record)): ?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">


<?php if($this->uri->segment(1)=='order-invoice'):?>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1898334310448944'); 
fbq('track', 'PageView');
	fbq('track', 'Purchase', {value: '<?php echo $record->order_total_amt;?>', currency: 'PKR'});
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1898334310448944&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

<?php endif;?>
</head>
<body>
<table background="" bgcolor="#e4e4e4" width="100%" style="padding:20px 0 20px 0" cellspacing="0" border="0" align="center" cellpadding="0">
  <tbody>
    <tr>
      <td><table width="500" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="border-radius: 5px; font-family: Arial, Helvetica, sans-serif">
          <tbody>
            <tr>
              <td style="text-align:center;padding-top:15px"><img style="width: 235px;" src="<?php echo site_url('uploads/settings/temp-logo.png');?>"></td>
            </tr>
            <tr>
              <td style="margin-top:100px;"></td>
            </tr>
            <tr>
              <td valign="top" style="color:#404041;line-height:16px;padding:25px 20px 0px 20px"><p> </p>
                <h3 align="center" style="margin-top: -12px;background-color: #FFF;clear: both;width:100%px;margin-right: auto;margin-left: auto;padding-left: 15px;padding-right: 15px; font-family: arial,sans-serif;">
					<span style="color:#46b560; font-size:25px;">Invoice</span> </h3>
                </section>
                <p style="text-align:center;"><strong>Hello, <?php echo (isset($record->order_name)?$record->order_name:'');?></strong></p> 
                <p style="text-align:center;">Thankyou for placing your order at The Skinfit.com<br/>Givien below is your Invoice Details.
                </p></td>
            </tr>
            <tr>
              <td valign="top" style="color:#404041;font-size:12px;line-height:16px;padding:25px 20px 0px 20px"><p> <span></span></p>
                <h4 style="color: #848484; font-family: arial,sans-serif; font-weight: 200;">Order # <?php echo (isset($record->order_no)?$record->order_no:'');?></h4>
                <?php $date = date_create((isset($record->order_created_date)? $record->order_created_date: ""))?>
				<h4 style="color: #848484; font-family: arial,sans-serif; font-weight: 200;">Date : <?php echo date_format($date,"d M, Y");?></h4>
				<h4 style="color: #848484; font-family: arial,sans-serif; font-weight: 200;">Delivery time 3-5 days.</h4>
                <p></p>
                <p> </p></td>
            </tr>
            <tr>
              <td style="color:#404041;font-size:12px;line-height:16px;padding:10px 16px 20px 18px"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-radius:5px;border:solid 1px #e5e5e5">
            </tr>
            <tr>
              <td style="color:#404041;font-size:12px;line-height:16px;padding:10px 16px 20px 18px; "><table width="100%" border="0" cellpadding="0" cellspacing="0" style="" >
                  <tbody>
                    <tr>
                    <td width="100%" colspan="5" align="left" valign="top" style="color:#404041;font-size:12px;line-height:16px;padding:5px 5px 15px 5px;border-bottom:dashed 1px #e5e5e5; font-family:Arial, Helvetica, sans-serif">
                       <h3>Order Details</h3> 
						<?php if(!empty($order_items)): foreach($order_items as $item): ?>
						<?php if($item->product_type == 'deal'):?> 
							<img src="<?php echo site_url('uploads/deal/').(isset($item->product_image)?$item->product_image:'');?>"  style="width:130px"><br>
					    <?php else:?>
							<img src="<?php echo site_url('uploads/product/').(isset($item->product_image)?$item->product_image:'');?>"  style="width:130px"><br>
					    <?php endif;?>	
							Product Name: <?php echo (isset($item->product_name)?$item->product_name:'');?><br>
							<?php if(!empty($item->product_variant)):?>
							Product Variation:
							<?php $options = unserialize($item->product_variant);?>
							<?php foreach($options as $option):?>
							<?php echo (isset($option)?$option:'');?><br>
							<?php endforeach;?> 
							<?php endif;?>
							Product Qty: <?php echo (isset($item->product_qty)?$item->product_qty:'');?><br>
							Product Price: <?php echo (isset($item->product_price)?$item->product_price:'');?></strong><br>
							<br>
						<?php endforeach; endif;?>
						<br>
						<strong>Sub Total: <?php echo (isset($record->order_actual_amt)?$record->order_actual_amt:'');?></strong><br>
						<strong>Discount: <?php echo (isset($record->order_disscount_amt)?$record->order_disscount_amt:'');?></strong><br>
						<strong>Shipping: <?php echo (isset($record->order_shipping_amt)?$record->order_shipping_amt:'');?></strong><br>
						<strong>Total: <?php echo (isset($record->order_total_amt)?$record->order_total_amt:'');?></strong><br>
				</tr>
					<tr>
                    <td width="100%" colspan="5" align="left" valign="top" style="color:#404041;font-size:12px;line-height:16px;padding:5px 5px 15px 5px;border-bottom:dashed 1px #e5e5e5; font-family:Arial, Helvetica, sans-serif">
                       <h3>Billing/Shipping Details</h3>
                        Name : <?php echo (isset($record->order_name)?$record->order_name:'');?><br>
                        E-mail: <?php echo (isset($record->order_email)?$record->order_email:'');?><br>
                        Phone No : <?php echo (isset($record->order_phone)?$record->order_phone:'');?><br>
                        State : <?php echo (isset($record->order_state)?$record->order_state:'');?><br>
                        City : <?php echo (isset($record->order_city)?$record->order_city:'');?><br>
                        Land Mark : <?php echo (isset($record->order_landmark)?$record->order_landmark:'');?><br>
                        Address : <?php echo (isset($record->order_address)?$record->order_address:'');?>
					</td>
                    </tr>
                    
                  </tbody>
                </table></td>
                <table>
                <tbody>
            <tr>
              <td style="padding-top:15px">We hope to see you again soon
              
              <br><br><strong><a href="://THESKINFIT.COM">THESKINFIT.COM</a></strong>     
                   
             <br><br> Have a question? EMAIL :<a href="mailto:HELP@THESKINFIT.COM">HELP@THESKINFIT.COM</a></td>
            </tr>
            
                  </tbody>
                </table>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
</body>
</html>
<?php endif;?>		