<?php if(!empty($products)): ?>
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
         <h1 class="banner-title"><?php echo !empty($category)?$category:''; ?></h1>
       <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">HOME</a>/</li>
            <?php if(!empty($sub_category)):?>
            <li><a href="<?php echo base_url('category/').$category_slug;?>"><?php echo !empty($category)?$category:''; ?></a>/</li>
            <li><span><?php echo !empty($sub_category)?$sub_category:'';?></span></li>
            <?php elseif(!empty($category)): ?>            
            <li><span><?php echo !empty($category)?$category:'';?></span></li>
            <?php elseif(!empty($search)): ?>            
            <li><span><?php echo !empty($search)?$search:'';?></span></li>
            <?php elseif(!empty($filter)): ?>            
            <li><span><?php echo !empty($filter)?$filter:'';?></span></li>
            <?php elseif(!empty($brand)): ?>             
            <li><span><?php echo !empty($brand)?$brand:'';?></span></li>
            <?php endif; ?>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->  
  
  <?php  if(!empty($products)):?>
  <!-- CONTAIN START -->
  <section class="ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 mb-sm-30">
          <div class="sidebar-block">
            <?php if($categories):?>
            <div class="sidebar-box listing-box mb-40"> <span class="opener plus"></span>
              <div class="sidebar-title">
                <h3><span>Categories</span></h3>
              </div>
              <div class="sidebar-contant">
                <ul>
                  <?php foreach($categories as $cat):?>  
                  <li>
                    <a href="javascript:;" class="category_tic" data-id="<?php echo !empty($cat->category_id)?$cat->category_id:''?>"><?php echo !empty($cat->category_name)?$cat->category_name:''?></a>
                    <i class="fa fa-check" style="<?php echo !empty($fl_arr['cat'])?in_array($cat->category_id,$fl_arr['cat'])?'':'display:none':'display:none'?>; color:#3bd0ad"></i> 
                  </li>
                  <?php endforeach;?>
                </ul>
              </div>
            </div>
            <?php endif;?>
            <div class="sidebar-box mb-40"> <span class="opener plus"></span>
              <div class="sidebar-title">
                <h3><span>Shop by</span></h3> 
              </div>
              <div class="sidebar-contant">                
                <?php if(!empty($prize_max) && !empty($prize_min)):?>
                <div class="price-range mb-30">
                  <div class="inner-title">Price range</div>
                  <input class="price-txt" data-min="<?php echo !empty($fl_arr['min'])?$fl_arr['min']:round($prize_min->product_reg_price)?>" data-max="<?php echo !empty($fl_arr['max'])?$fl_arr['max']:round($prize_max->product_reg_price)?>" type="text" id="amount">
                  <div id="slider-range"></div>
                </div>
                <?php endif;?>                
                <?php if($variants): $arr = array();?>  
                <?php foreach($variants as $attr): if(!in_array($attr->attribute_name,$arr)): array_push($arr,$attr->attribute_name);?>                    
                <div class="size mb-20">
                  <div class="inner-title"><?php echo !empty($attr->attribute_name)?$attr->attribute_name:''?></div>
                  <ul>                  
                    <?php foreach($variants as $var): if($var->attribute_id == $attr->attribute_id):?> 
                    <li>
                        <a href="javascript:;" class="variant_tic" data-id="<?php echo !empty($var->variant_id)?$var->variant_id:''?>">
                        <?php echo !empty($var->variant_name)?$var->variant_name:''?>
                        </a>   
                        <i class="fa fa-check" style="<?php echo !empty($fl_arr['var'])?in_array($var->variant_id,$fl_arr['var'])?'':'display:none':'display:none'?>; color:#3bd0ad"></i>   
                    </li>                    
                    <?php endif; endforeach;?>  
                  </ul>
                </div>
                <?php endif; endforeach;?>                  
                <?php endif;?>
                
                <?php if($brands):?>            
                <div class="mb-20">
                  <div class="inner-title">Brand's</div>
                  <ul>
                  <?php foreach($brands as $brand):?>  
                    <li><a href="javascript:;" class="brand_tic" data-id="<?php echo !empty($brand->brand_id)?$brand->brand_id:''?>"><?php echo !empty($brand->brand_name)?$brand->brand_name:''?></a>
                        <i class="fa fa-check" style="<?php echo !empty($fl_arr['bnd'])?in_array($brand->brand_id,$fl_arr['bnd'])?'':'display:none':'display:none'?>; color:#3bd0ad"></i>                     
                    </li>    
                  <?php endforeach;?>
                  </ul>
                </div>
                <?php endif;?>
             
                <?php if($filters):?>            
                <div class="mb-20">
                  <div class="inner-title">Filter's</div>
                  <ul>
                  <?php foreach($filters as $filter):?>  
                    <li>
                        <a href="javascript:;" class="filter_tic" data-id="<?php echo !empty($filter->filter_id)?$filter->filter_id:''?>"><?php echo !empty($filter->filter_name)?$filter->filter_name:''?></a>                     
                        <i class="fa fa-check" style="<?php echo !empty($fl_arr['fil'])?in_array($filter->filter_id,$fl_arr['fil'])?'':'display:none':'display:none'?>; color:#3bd0ad"></i>                   
                    </li>
                  <?php endforeach;?>
                  </ul>
                </div>
                <?php endif;?>
                                 
                <a href="javascript:;" id="rest_filter" class="btn btn-color">Rest</a>
                <a href="javascript:;" id="refine_filter" class="btn btn-color">Filter</a>
              </div>
            </div>
            <div class="sidebar-box mb-40 d-none d-lg-block"> 
              <a href="<?php echo !empty($this->adds->adds_link)?$this->adds->adds_link:'javascript:;';?>"> 
                <img src="<?php echo !empty($this->adds->adds_image)?base_url('uploads/adds/').$this->adds->adds_image:'';?>" alt="Stylexpo"> 
              </a> 
            </div>
          </div>
        </div>
        <div class="col-lg-9">
          <div class="product-listing">
            <div class="inner-listing">
              <div class="row">
                <?php foreach($products as $row): ?>
                <div class="col-md-4 col-6 mb-30">
                  <div class="product-item">
                    <div class="product-image">
                        <a href="<?php echo base_url('product/').$row->product_slug?>"> 
                            <img src="<?php echo base_url('uploads/product/').$row->product_image;?>" alt="Stylexpo"> 
                        </a>
                      <div class="product-detail-inner">
                        <div class="detail-inner-left align-center">
                          <ul>
                              <li class="pro-cart-icon">
                                <form method="post">
                                  <button type="button" onclick="location.href = '<?php echo base_url()."product/".$row->product_slug;?>';" title="Add to Cart"><span></span>Add to Cart</button>
                                </form>
                              </li>
                              <li class="pro-wishlist-icon add_to_wish" data-id="<?php echo $row->product_id;?>"><a href="javascript:;" title="Wishlist"></a></li>
                              <li class="pro-compare-icon add_to_compare" data-id="<?php echo $row->product_id;?>"><a href="javascript:;" title="Compare"></a></li>
                            
                            </ul>
                        </div>
                      </div>
                    </div>
                    <div class="product-item-details">
                      <div class="product-item-name"> 
                          <a href="<?php echo base_url('product/').$row->product_slug?>">
                            <?php echo $row->product_name?>
                          </a>
                      </div>
                      <div class="price-box">
                          <span class="price">
                            <?php echo  $this->currency; echo $row->product_dis_price > 0? $row->product_dis_price:$row->product_reg_price; ?>
                          </span> 
                          <del class="price old-price">
                            <?php echo $row->product_dis_price > 0? $this->currency . $row->product_reg_price:'';?>
                          </del> 
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
  <?php else:?>                
  <section class="ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="mb-30 mt-30">
            <h1>No Products In This Category</h1>
          </div>
        </div>
      </div>
    </div>
  </section>
 <?php endif; ?>