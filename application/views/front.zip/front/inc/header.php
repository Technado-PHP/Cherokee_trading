<!DOCTYPE html>
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
<!-- Basic Page Needs
  ================================================== -->
<meta charset="utf-8">
<title><?php echo !empty($this->site_title)?$this->site_title:''?></title>
<!-- SEO Meta
  ================================================== -->
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="">
<meta name="keywords" content="">


<!-- Mobile Specific Metas
  ================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- CSS
  ================================================== -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/font-awesome.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/fotorama.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/custom.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/');?>css/responsive.css">
<link rel="shortcut icon" href="<?php echo base_url('uploads/settings/').$this->fav_icon;?>">
<link rel="apple-touch-icon" href="<?php echo base_url('assets/front/');?>images/apple-touch-icon.html">
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url('assets/front/');?>images/apple-touch-icon-72x72.html">
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url('assets/front/');?>images/apple-touch-icon-114x114.html">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/admin/css/alert.css');?>"/>
<script src="<?php echo base_url('assets/front/');?>js/jquery-1.12.3.min.js"></script>
<script src="<?php echo base_url('assets/admin/js/alert.js');?>"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
  <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130866126-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130866126-1');
</script>


<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '1898334310448944'); 
fbq('track', 'PageView');
<?php if($this->uri->segment(1)=='cart'):?>
	fbq('track', 'AddToCart');
<?php endif;?>

</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=1898334310448944&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
  
</head>

<body class="homepage">
    
<style>
  .toast-top-right{ top:43% !important; right:39% !important;background-color: #20a9d2!important}
  .vl {border-left: 3px solid green; height:100px;}
</style>

<?php if($this->session->flashdata('success')):?>
  <script>alert_success("<?php echo $this->session->flashdata('success')?>");</script>
<?php endif;?>
<?php if($this->session->flashdata('error')):?> 
  <script>alert_danger("<?php echo $this->session->flashdata('error')?>");</script>
<?php endif;?>

<?php if(empty($this->uri->segment(1))):?>
<!--<div class="se-pre-con"></div> -->
<?php endif;?>
<div id="newslater-popup" class="mfp-hide white-popup-block open align-center">
  <div class="nl-popup-main">
    <div class="nl-popup-inner">
      <div class="newsletter-inner">
        <h2 class="main_title">BECOME AN INSIDER</h2>
        <form action="<?php echo base_url('newsletter');?>" method="post">
          <input type="email" name="newsletter_email" placeholder="Email Here..." required>
          <button class="btn-black" title="Subscribe">Subscribe</button>
        </form>
        <h4>Enjoy <span>FREE SHIPPING</span> on invoice Rs 6000 or above</h4>
        <p>Be the first to hear about new products, exlusive offers and many more!</p>
       </div>
    </div>
  </div>
</div>
<div class="main">
 
  <!-- HEADER START -->
  <header class="navbar navbar-custom container-full-sm" id="header">
    <div class="header-top">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-6">
              <div class="left-side" style="padding: 10px 0">
              <div class="help-num" ><i class="fa fa-phone"> </i> Need Help? : <?php echo !empty($this->phone)?$this->phone:''?></div>
            </div>
            <div class="top-right-link right-side">
              <ul>
                <li class="login-icon content">
                  <a class="content-link">
                  <span class="content-icon"></span> 
                  </a> 
                  <?php if(!$this->session->userdata('customer_id')):?>
                  <a href="<?php echo base_url('login');?>" title="Login">Login</a> or
                  <a href="<?php echo base_url('register');?>" title="Register">Register</a>
                  <?php else:?>
                  <a href="<?php echo base_url('my-account');?>" title="My Account">My Account</a> /  
                  <a href="<?php echo base_url('login/logout');?>" title="Logout">Logout</a>               
                  <?php endif;?>
                  <div class="content-dropdown">
                    <ul>
                      <li class="login-icon"><a href="<?php echo base_url('login');?>" title="Login"><i class="fa fa-user"></i> Login</a></li>
                      <li>Free Delivery Over <span>Orders RS.6000</span></li>
                      <li class="register-icon"><a href="<?php echo base_url('register');?>" title="Register"><i class="fa fa-user-plus"></i> Register</a></li>
                    </ul>
                  </div>
                </li>
                <li style="line-height: 24px;">Free Delivery <span style="font-size: 11px;">Over Orders RS.6000</span></li>
                <!--
                <li class="track-icon">
                  <a href="#" title="Track your order"><span></span> Track your order</a>
                </li>
                -->
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-middle">
      <div class="container">
        <div class="row">
          <div class="col-xl-3 col-md-3 col-lgmd-20per">
            <div class="header-middle-left">
              <div class="navbar-header float-none-sm">
                <a class="navbar-brand page-scroll" href="<?php echo base_url('');?>">
                  <img alt="logo" src="<?php echo base_url('uploads/settings/').$this->header_logo;?>">
                </a> 
              </div>
            </div>
          </div>
          <div class="col-xl-6 col-md-6 col-lgmd-60per">
            <div class="header-right-part">
              <div class="main-search">
                <div class="header_search_toggle desktop-view">
                    <div class="search-box">
                      <input class="input-text" id="search-name" type="text" placeholder="Search entire store here...">
                      <button class="search-btn"></button>
                    </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-3 col-lgmd-20per">
            <div class="right-side float-left-xs header-right-link">
              <ul>
                <li class="compare-icon">
                  <a href="<?php echo base_url('compare');?>">
                    <span></span>
                  </a>
                </li>
                <li class="wishlist-icon">
                  <a href="<?php echo base_url('wishlist');?>">
                    <span></span>
                  </a>
                </li>
                <li class="cart-icon"> <a href="<?php echo base_url('my-cart');?>"> <span> <small class="cart-notification"><?php echo $this->cart->total_items();?></small> </span> </a>
                  <?php if($this->cart->contents()):?>
                <!--  <div class="cart-dropdown header-link-dropdown">
                    <ul class="cart-list link-dropdown-list">
                      <?php foreach ($this->cart->contents() as $items): ?>                
                      <li> <a class="close-cart"><i class="fa fa-times-circle"></i></a>
                        <div class="media"> <a class="pull-left"> <img alt="Stylexpo" src="<?php echo !empty($items['image'])?base_url('uploads/product/').$items['image']:'';?>"></a>
                          <div class="media-body"> <span><a href="javscript:;"><?php echo !empty($items['name'])?$items['name']:'';?></a></span>
                            <p class="cart-price"><?php echo !empty($items['price'])?$this->currency.$items['price']:'';?></p>
                            <div class="product-qty">
                              <label>Qty:</label>
                              <div class="custom-qty">
                                <input type="text" name="qty" maxlength="8" value="<?php echo !empty($items['qty'])?$items['qty']:'';?>" title="Qty" class="input-text qty">
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <?php endforeach; ?>
                    </ul>
                    <p class="cart-sub-totle"> <span class="pull-left">Cart Subtotal</span> <span class="pull-right"><strong class="price-box"><?php echo !empty($items['subtotal'])?$this->currency.$items['subtotal']:'';?></strong></span> </p>
                    <div class="clearfix"></div>
                    <div class="mt-20"> <a href="<?php echo base_url('my-cart');?>" class="btn-color btn">Cart</a> <a href="<?php echo base_url('checkout');?>" class="btn-color btn right-side">Checkout</a> </div>
                  </div> -->
                  <?php endif;?>  
                </li>
                <li class="side-toggle">
                  <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"><i class="fa fa-bars"></i></button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-bottom"> 
      <div class="container position-s">
        <div class="row">
          <div class="col-lg-12 col-md-12 position-initial">
            <div id="menu" class="navbar-collapse collapse" >
              <div class="top-right-link mobile right-side">
                <ul>
                  <li class="login-icon content">
                    <a class="content-link">
                    <span class="content-icon"></span> 
                    </a> 
                    <a href="<?php echo base_url('login');?>" title="Login">Login</a> or
                    <a href="<?php echo base_url('register');?>" title="Register">Register</a>
                    <div class="content-dropdown">
                      <ul>
                        <li class="login-icon"><a href="<?php echo base_url('login');?>" title="Login"><i class="fa fa-user"></i> Login</a></li>
                        <li class="register-icon"><a href="<?php echo base_url('register');?>" title="Register"><i class="fa fa-user-plus"></i> Register</a></li>
                      </ul>
                    </div>
                  </li>
                  <!--
                  <li class="track-icon">
                    <a title="Track your order"><span></span> Track your order</a>
                  </li>
                  -->
                </ul>
              </div>
                 <ul class="nav navbar-nav">
 
                  <?php $cate = get_category();?>
                  <?php if(!empty($cate)): foreach($cate as $col): ?>
                  
                <li class="level dropdown"> <span class="opener plus"></span> <a href="<?php echo base_url('category/').$col->category_slug;?>" class="page-scroll"><?php echo $col->category_name;?></a>
                  <div class="megamenu mobile-sub-menu">
                    <div class="megamenu-inner-top">
                       <ul class="sub-menu-level1">
                        <li class="level2 ">  
                          <ul class="sub-menu-level2">
                              <?php $subcol = get_list('sub_category',array('category_id'=>get_single_id($col->category_id))); $x = count($subcol)/2; $i=0;?>
                              <?php if(!empty($subcol)): for($i=0; $i < $x; $i++):?>
                            <li class="level3"><a href="<?php echo base_url('sub-category/').$subcol[$i]->sub_category_slug;?>"><span>■</span><?php echo $subcol[$i]->sub_category_name;?></a></li>
                            <?php endfor; endif; ?>
                          </ul>
                        </li>
                        <li class="level2 ">
                          <ul class="sub-menu-level2">
                              <?php if(!empty($subcol)): for($i=$i; $i < count($subcol); $i++):?>
                            <li class="level3"><a href="<?php echo base_url('sub-category/').$subcol[$i]->sub_category_slug;?>"><span>■</span><?php echo $subcol[$i]->sub_category_name;?></a></li>
                            <?php endfor; endif; ?>
                          </ul>
                        </li>
                        <li class="level2">
                          <div class="megamenu-inner-bottom mt-20 d-none d-lg-block">
                            <a href="<?php echo base_url('category/').$col->category_slug;?>">
                              <img style="max-width:300px;" src="<?php echo base_url('uploads/category/').$col->category_image;?>" alt="Parent Category Image">
                            </a>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </li>
                <?php endforeach; endif; ?>
                <li style="border:1px solid #fff" class="level btn-color"><a href="<?php echo base_url('deal');?>">Deals</a><li>

              </ul>
              <div class="header-top mobile">
                <div class="">
                  <div class="row">
                    <div class="col-12">
                      <div class="top-link right-side">
                        <div class="help-num" ><i class="fa fa-phone"> </i> Need Help? : <?php echo !empty($this->phone)?$this->phone:''?></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


  </header>
  <!-- HEADER END -->  