 <!-- News Letter Start -->
  <section>
    <div class="newsletter">
      <div class="container">
        <div class="newsletter-inner center-sm">
          <div class="row">
            <div class=" col-xl-12 col-md-12">
              <div class="newsletter-bg">
                <div class="row">
                  <div class="col-lg-5">
                    <div class="newsletter-title">
                      <h2 class="main_title">Subscribe to our newsletter</h2>
                      <div class="sub-title">Be the first to hear about new products, exclusive offers and many more!</div> 
                    </div>
                  </div>
                  <div class="col-lg-7">
                    <form method="post" action="<?php echo base_url('contact/newsletter');?>">
                      <div class="newsletter-box">
                        <input type="email" name="newsletter_email" placeholder="Email Here...">
                        <button type="submit" title="Subscribe" class="btn-color">Subscribe</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- News Letter End --> 

  <!-- FOOTER START -->
  <div class="footer">
    <div class="container">
      <div class="footer-inner">
        <div class="footer-middle">
          <div class="row">
            <div class="col-xl-3 f-col">
              <div class="footer-static-block"> <span class="opener plus"></span>
                <h3 class="title">Information <span></span></h3>
                <ul class="footer-block-contant link">
                  <li><a href="<?php echo base_url('about-us');?>">About Us</a></li>
                  <li><a href="<?php echo base_url('contact-us');?>">Contact Us </a></li>
                  <li><a href="<?php echo base_url('delivery-information');?>">Delivery Information</a></li>
                  <li><a href="<?php echo base_url('return-refund');?>">Return & Refund Policy</a></li>
                </ul>
              </div>
            </div>
            <div class="col-xl-3 f-col">
              <div class="footer-static-block"> <span class="opener plus"></span>
                <h3 class="title">Payment Methods <span></span></h3>
                <ul class="footer-block-contant link">
                  <li><a href="javascript:;">Cash on Delivery </a></li>
                  <li><a href="javascript:;">Bank Transfer </a></li>
                </ul>
              </div>
            </div>
            <div class="col-xl-3 f-col">
              <div class="footer-static-block"> <span class="opener plus"></span>
                <h3 class="title">My Account <span></span></h3>
                <ul class="footer-block-contant link">
                  <li><a href="<?php echo base_url('my-account');?>">My Account </a></li>
                  <li><a href="<?php echo base_url('wishlist');?>">Wishlist </a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <hr>
        <div class="footer-bottom ">
          <div class="row mtb-30">
            <div class="col-lg-6 ">
              <div class="copy-right ">© <?php echo date('Y')?> All Rights Reserved <?php echo !empty($this->site_title)?$this->site_title:''?></div>
            </div>
            <div class="col-lg-6 ">
              <div class="footer_social pt-xs-15 center-sm">
                <ul class="social-icon">
                  <li><div class="title">Follow us on :</div></li>
                  <?php if(!empty($this->social)): foreach($this->social as $sc): if(!empty($sc->social_link)):?>                  
                  <li><a target="_blank" href="<?php echo !empty($sc->social_link)?$sc->social_link:''?>" 
                  title="<?php echo !empty($sc->social_name)?$sc->social_name:''?>" 
                  class="<?php echo !empty($sc->social_name)?$sc->social_name:''?>">
                  <i class="<?php echo !empty($sc->social_icon)?$sc->social_icon:''?>"> </i></a></li>
                  <?php endif; endforeach; endif;?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="scroll-top">
    <div class="scrollup"></div>
  </div>
  <!-- FOOTER END --> 
</div>
<script src="<?php echo base_url('assets/front/');?>js/tether.min.js"></script> 
<script src="<?php echo base_url('assets/front/');?>js/bootstrap.min.js"></script>  
<script src="<?php echo base_url('assets/front/');?>js/jquery.downCount.js"></script>
<script src="<?php echo base_url('assets/front/');?>js/jquery-ui.min.js"></script> 
<script src="<?php echo base_url('assets/front/');?>js/fotorama.js"></script>
<script src="<?php echo base_url('assets/front/');?>js/jquery.magnific-popup.js"></script> 
<script src="<?php echo base_url('assets/front/');?>js/owl.carousel.min.js"></script>  
<script src="<?php echo base_url('assets/front/');?>js/custom.js"></script>
<script src="<?php echo base_url();?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>

<script>
$(document).ready(function(){
  $('input[type=phone]').inputmask({"mask": "9999-9999999","clearIncomplete": true }); //specifying options
})


$(document).ready(function(){
    $(".navbar-nav").on('click','li > a',function(){
        $('.navbar-toggle').trigger('click');
        	
    });
	$(".deal_cart").on('click',function(){
        var form = $(this);
        $.ajax({
			type: "POST",
			url: "<?php echo base_url('cart/add');?>",  
			data: {deal_id:form.data('id')},		
			dataType: "json",			
			success: function(data){ 
                $('.cart_pop').toggle();  
                console.log(data.count);
                $('.cart-notification').text(data.count);
                toastr.success('Added To Cart.');
			},
			error: function(data) {
                toastr.error('Something Went Wrong, Please Try Again Later.')
			},
		});		
    });
	$("#cart_submit").submit(function(e){
		e.preventDefault();
        var form = $(this);
        $.ajax({
			type: "POST",
			url: "<?php echo base_url('cart/add');?>",  
			data: form.serialize(),		
			dataType: "json",			
			success: function(data){ 
			    if(data.status == 'success'){
                    $('.cart_popup').toggle();
                console.log(data.count);
                $('.cart-notification').text(data.count);    
			    }else{
                    toastr.error(data.msg);   
			    }
			},
			error: function(data) {
                toastr.error('Something Went Wrong, Please Try Again Later.')
			},  
		});		
    });
    
    $(".increase.cart").on('click',function(){
        var result = parseInt($(this).prev().val()); 
        $(this).prev().val(result+1);

    });
    $(".reduced.cart").on('click',function(){
        var result = parseInt($(this).next().val());
        if(result > 0){
            $(this).next().val(result-1);  
        }else{
            $(this).next().val(0);
        }      
        
    });
    
    
     $("#cart_update").on('click',function(){
        var rowid = [];
        var qty = [];
        var id = [];
        $('.cart-qty').each(function(i){
           qty.push($(this).val());
           rowid.push($(this).data('id'));
           id.push($(this).data('proid'));
        });
        $.ajax({
			type: "POST",
			url: "<?php echo base_url('cart/update');?>",  
			data: {rowid:rowid,qty:qty,id:id},		
			dataType: "html",	
            success: function(data){
            
               window.location.reload();
			},
		});	
     });	
    
    $(".cart-remove-item").on('click',function(){
        var x = $('.cart-remove-item').length;
        var temp = $(this).parents('tr');
        $.ajax({
			type: "POST",
			url: "<?php echo base_url('cart/remove');?>",  
			data: {rowid:$(this).data('id')},		
			dataType: "html",			
			success: function(data){
			    if(x == 1){
			        window.location.reload();
			    }else{
			       $(temp).remove(); 
			    }
                toastr.success('Updated Successfully')
			},
			error: function(data) {
                toastr.error('Something Went Wrong, Please Try Again Later.')
			},
		});	
    }); 
    
});
</script>    
<script> 
$(document).ready(function(){   
    $(".search-btn").on('click',function(){
        var search_url = '<?php echo base_url("search")?>?value='+$('#search-name').val();       
        window.location.href = search_url;  
    })
    
    $(".atrr_var").on('change',function(){
        value = 0;
        var val = $('#actual_price').val();
        $("select.atrr_var").each(function(){
            $(this).children("option:selected").each(function(){
                var ac = $(this).text().split("(+");
                var temp = ac[1].replace(/[^.0-9]/gi, '');
                temp = temp ? temp : 0;
                var amt = parseFloat(temp);
                value = value+amt;
            });
        });
        value =  parseFloat(val)+parseFloat(value);
        $('.price.fn').text('Rs.'+  +value);
    })
    
    $(".add_to_wish").on('click',function(){
      $.ajax({
        url: '<?php echo base_url("home/wishlist")?>',
        type: 'post',
        data: {product_id:$(this).data("id"),
      },
      success: function(data) {

        if(data == 1){
          toastr.success('Added To Wishlist.')
        }else if(data == 2){
          toastr.error('Something Went Wrong, Please Try Again Later.')
        }
        else if(data == 3){
          toastr.error('Already in your wishlist')
        }

      }
    });
    }); 


    $(".remove_wish").on('click',function(){
      $.ajax({
        url: '<?php echo base_url("home/wishlist_remove")?>',
        type: 'post',
        data: {wishlist_id:$(this).data("id"),
      },
      success: function(data) {

        if(data == 1){
          toastr.success('Removed From Wishlist.')
        }else if(data == 2){
          toastr.error('Something Went Wrong, Please Try Again Later.')
        }
        document.location.reload();

      }
    });
    }); 

    
    $(".add_to_compare").on('click',function(){
      $.ajax({
        url: '<?php echo base_url("home/compare")?>',
        type: 'post',
        data: {product_id:$(this).data("id"),
      },
      success: function(data) {
        console.log(data);    
        if(data == 1){
          toastr.success('Added To Compare.')
        }else if(data == 2){
          toastr.error('Something Went Wrong, Please Try Again Later.')
        }
        else if(data == 3){
          toastr.error('Already Added')
        }

      }
    });
    }); 


    $(".remove_compare").on('click',function(){
      $.ajax({
        url: '<?php echo base_url("home/compare_remove")?>',
        type: 'post',
        data: {product_id:$(this).data("id"),
      },
      success: function(data) {

        if(data == 1){
          toastr.success('Removed From Compare.')
        }else if(data == 2){
          toastr.error('Something Went Wrong, Please Try Again Later.')
        }
        document.location.reload();

      }
    });
    }); 
    
  });  
</script>
<?php if(empty($this->uri->segment(1))):?>
<script>
  /* ------------ Newslater-popup JS Start ------------- */
$(document).ready(function() {
    setTimeout(function() {
        $.magnificPopup.open({
        items: {src: '#newslater-popup'},type: 'inline'}, 0);
    }, 5000);
});  
    /* ------------ Newslater-popup JS End ------------- */
</script>
<?php endif;?>
<script>
$(document).ready(function() {
 price_range ();
/* Price-range Js Start */
  function price_range () {
      $( "#slider-range" ).slider({
        range: true,
        min: $('#amount').data('min'),
        max: $('#amount').data('max'),
        values: [ $('#amount').data('min'), $('#amount').data('max') ],
        slide: function( event, ui ) {
          $( "#amount" ).val( "Rs." + ui.values[ 0 ] + " - Rs." + ui.values[ 1 ] );
        }
      });
      $( "#amount" ).val( "Rs." + $( "#slider-range" ).slider( "values", 0 ) + " - Rs." + $( "#slider-range" ).slider( "values", 1 ) );
  }
  /* Price-range Js End */
});   
</script>
<script>
$(document).ready(function() {
    $(".variant_tic").on('click',function(){
        if($(this).hasClass('active')){
            $(this).removeClass('active');
            $(this).next('i').hide();
        }else{
            $(this).addClass('active');    
            $(this).next('i').show();        
        }
    });
    
    $(".filter_tic").on('click',function(){
        if($(this).hasClass('active')){
            $(this).removeClass('active');
            $(this).next('i').hide();
        }else{
            $(this).addClass('active');    
            $(this).next('i').show();        
        }
    });
    
    $(".brand_tic").on('click',function(){
        if($(this).hasClass('active')){
            $(this).removeClass('active');
            $(this).next('i').hide();
        }else{
            $(this).addClass('active');    
            $(this).next('i').show();        
        }
    });
    
    $(".category_tic").on('click',function(){
        if($(this).hasClass('active')){
            $(this).removeClass('active');
            $(this).next('i').hide();
        }else{
            $(this).addClass('active');    
            $(this).next('i').show();        
        }
    });
    
    $("#rest_filter").on('click',function(){
        var all = $('.category_tic, .brand_tic, .filter_tic, .variant_tic');
        if($(all).hasClass('active')){
            $(all).removeClass('active');
            $(all).next('i').hide();   
        }    
    });
    
    $("#apply-coupon").on('click',function(){
        
        window.location.href = "<?php echo base_url()?>home/coupon?code="+$("#coupon-code").val();
        
      
    });
    
    $("#refine_filter").on('click',function(){     
    
        var cat_val = '';         
        var var_val = '';         
        var bnd_val = '';         
        var fil_val = ''; 
        var min_val = ''; 
        var max_val = ''; 
        
        $('.category_tic').each(function(){
            if($(this).hasClass('active')){
                cat_val += $(this).data('id') + ',';
            }    
        });    
        
        $('.variant_tic').each(function(){
            if($(this).hasClass('active')){
                var_val += $(this).data('id') + ',';
            }    
        });
        
        $('.brand_tic').each(function(){
            if($(this).hasClass('active')){
                bnd_val += $(this).data('id') + ',';
            }    
        });
        
        $('.filter_tic').each(function(){
            if($(this).hasClass('active')){
                fil_val += $(this).data('id') + ',';
            }    
        });
        
        min_val = $('.price-txt').data('min');
        max_val = $('.price-txt').data('max');
        
        window.location.href = "<?php echo base_url()?>filter/?ct="+cat_val+"&vr="+var_val+"&br="+bnd_val+"&fl="+fil_val+"&min="+min_val+"&max="+max_val+"";
    });   
    
    
    
});  
</script>
</body>

</html>
