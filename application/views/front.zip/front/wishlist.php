     <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Wishlist</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="index.html">Home</a>/</li>
            <li><span>Wishlist</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->
  <!-- CONTAIN START -->
  <section class="ptb-70">
    <div class="container">
      <div class="row">
          <?php if(!empty($wishdata)): foreach($wishdata as $wish): ?>
            <?php $row = get_list('product',array('product_id'=>$wish->product_id))?>
                <div class="col-md-3 mb-30">
                  <div class="product-item">
                    <div class="product-image"> <a href="<?php echo base_url('product-detail/').$row[0]->product_slug;?>"> <img src="<?php echo base_url('uploads/product/').$row[0]->product_image;?>" alt="Stylexpo"> </a>
                      <div class="product-detail-inner">
                        <div class="detail-inner-left align-center">
                          <ul>
                            <li class="pro-cart-icon">
                              <form>
                                <button title="Add to Cart"><span></span>Add to Cart</button>
                              </form>
                            </li>
                            <li class="pro-wishlist-icon remove_wish" data-id="<?php echo $wish->wishlist_id;?>"><a href="javascript:" title="Wishlist"></a></li>
                            <li class="pro-compare-icon"><a href="compare.html" title="Compare"></a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="product-item-details">
                      <div class="product-item-name"> <a href="<?php echo base_url('product-detail/').$row[0]->product_slug;?>"><?php echo $row[0]->product_name?></a> </div>
                      <div class="price-box"> <span class="price"><?php echo  $this->currency; echo $row[0]->product_dis_price > 0? $row[0]->product_dis_price:$row[0]->product_reg_price; ?></span> <del class="price old-price"><?php echo $row[0]->product_dis_price > 0? $this->currency . $row[0]->product_reg_price:''; 
                            ?></del> </div>
                    </div>
                  </div>
                </div> 

              <?php endforeach;?>
                <?php else: ?>
                  <h4>No product Found</h4>
              <?php endif; ?>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
  
 