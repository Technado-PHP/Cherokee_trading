        
  
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Account</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="index.html">Home</a>/</li>
            <li><span>Account</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->

  <!-- CONTAIN START -->
  <section class="checkout-section ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="account-sidebar account-tab mb-sm-30">
            <div class="dark-bg tab-title-bg">
              <div class="heading-part">
                <div class="sub-title"><span></span> My Account</div>
              </div>
            </div>
            <div class="account-tab-inner">
              <ul class="account-tab-stap">
                <li id="step1" class="active"> <a href="javascript:void(0)">Account Details<i class="fa fa-angle-right"></i> </a> </li>
                <li id="step2"> <a href="javascript:void(0)">My Order List<i class="fa fa-angle-right"></i> </a> </li>
                <li id="step3"> <a href="javascript:void(0)">Change Password<i class="fa fa-angle-right"></i> </a> </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-lg-9">
          <div id="data-step1" class="account-content" data-temp="tabdata">
            <div class="row">
              <div class="col-12">
                <div class="heading-part heading-bg mb-30">
                  <h2 class="heading m-0">Account Details</h2>
                </div>
              </div>
            </div>
            <div class="m-0">
              <form class="main-form full" action="<?php echo base_url('my-account');?>" method="post">
                <div class="mb-20">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="input-box">
                        <input type="text" name="customer_name" value="<?php echo !empty($customer->customer_name)?$customer->customer_name:''?>" required placeholder="Full Name">
                        <?php echo form_error('customer_name'); ?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="input-box">
                        <input type="email" name="customer_email" value="<?php echo !empty($customer->customer_email)?$customer->customer_email:''?>" required placeholder="Email Address">
                        <?php echo form_error('customer_email'); ?>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="input-box">
                        <input type="phone" name="customer_phone" value="<?php echo !empty($customer->customer_phone)?$customer->customer_phone:''?>" required placeholder="Contact Number">
                        <?php echo form_error('customer_phone'); ?>
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="input-box">
                        <input type="text" name="customer_address" value="<?php echo !empty($customer->customer_address)?$customer->customer_address:''?>" required placeholder="Shipping Address">
                        <span>Please enter the complete address.</span> 
                        <?php echo form_error('customer_address'); ?>
                      </div>
                    </div>
                    <div class="col-12">
                      <button class="btn-color" type="submit" name="submit">Update</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div id="data-step2" class="account-content" data-temp="tabdata" style="display:none">
            <div id="form-print" class="admission-form-wrapper">
              <div class="row">
                <div class="col-12">
                  <div class="heading-part heading-bg mb-30">
                    <h2 class="heading m-0">My Orders</h2>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12 mb-xs-30">
                  <div class="cart-item-table commun-table">
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr>
                            <th>Order No</th> 
                            <th>Tracking No</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Invoice</th> 
                          </tr>
                        </thead>
                        <tbody>
                            <?php if($orders): foreach($orders as $order):?>
                          <tr>
                            <td><?php echo $order->order_no?></td>
                            <td><?php echo $order->order_tracking_no?></td>
                            <td><?php echo $order->order_total_amt?></td>
                            <td><?php echo $order->order_current_status?></td>
                            <td><?php echo date_format(date_create($order->order_created_at),'Y-m-d')?></td>
                            <td><a target="_blank" href="<?php echo base_url('invoice/').$order->order_no?>">View</a></td>
                          </tr>
                          <?php endforeach;endif;?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12">
                <div class="print-btn text-center mt-30">
                  <button onclick="printDiv('form-print')" class="btn btn-color" type="button">Print</button>
                </div>
              </div>
           </div>
          </div>
          <div id="data-step3" class="account-content" data-temp="tabdata" style="display:none">
            <div class="row">
              <div class="col-12">
                <div class="heading-part heading-bg mb-30">
                  <h2 class="heading m-0">Change Password</h2>
                </div>
              </div>
            </div>
            <form class="main-form full" action="<?php echo base_url('my-account/password');?>" method="post">
              <div class="row">
                <div class="col-12">
                  <div class="input-box">
                    <label for="old-pass">Old-Password</label>
                    <input type="password" placeholder="Old Password" name="old_password" required id="old-pass">
                        <?php echo form_error('old_password'); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="input-box">
                    <label for="login-pass">Password</label>
                    <input type="password" placeholder="Enter your Password" name="new_password" required id="login-pass">
                        <?php echo form_error('new_password'); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="input-box">
                    <label for="re-enter-pass">Re-enter Password</label>
                    <input type="password" placeholder="Re-enter your Password" name="confirm_password" required id="re-enter-pass">
                        <?php echo form_error('confirm_password'); ?>
                  </div>
                </div>
                <div class="col-12">
                  <button class="btn-color" type="submit" name="submit">Change Password</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
 <script> 
 $(document).ready(function(){
     var url = window.location.href;
     if(url.indexOf("password") >= 0){
         $('#step3').addClass('active');
         $('#step2').removeClass('active');
         $('#step1').removeClass('active');
         $('#data-step3').show();
         $('#data-step2').hide();
         $('#data-step1').hide();
     }
});
 </script>