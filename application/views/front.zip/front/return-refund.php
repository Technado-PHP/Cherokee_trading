    
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs"> 
        <h1 class="banner-title">Delivery information</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Delivery information</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->  
  
  <!-- CONTAIN START ptb-95-->
  <section class="ptb-70">
    <div class="container">
      <div class="row">
          <div class="row">
            <div class="col-8 offset-2">
              <h3>Returns & Refund Policy</h3>
              <br><br><br>
              <ul style="list-style:disc inside;">
                  <li>We accept return and refund only if product is sealed and in sound condition with in 15 days of delivery.</li>
                  <li>Payment can be refund or order can be modified after product audit.</li>
                  <li>Process time 3-5 days after we receive the product.</li>
                  <li>Payment will be transferred back to you via bank transfer only.</li>
                  <li>Charges – Shipping charges, and bank charges will be on customer.</li>
              </ul> 
            </div>
          </div>
        </div>
  </section>