    
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Delivery information</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Delivery information</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->  
  
  <!-- CONTAIN START ptb-95-->
  <section class="ptb-70">
    <div class="container">
      <div class="row">
          <div class="row">
            <div class="col-8 offset-2">
              <h5>Thank you for visiting and shopping at THE SKINFIT.</h5>
              <h6 style="text-transform: unset;">Our Shipping Policy is given below</h6>
              <br><br><br>
              <h5>Delivery Duration</h5>
              <ul style="list-style:disc inside;">
                  <li>Orders are processed and delivered within 3-5 business days.</li>
                  <li>No deliveries on Weekends or Holidays.</li>
                  <li>Please allow additional days in transit for delivery during Holidays and occasions.</li>
                  <li>Deliveries will be done by courier service and they deliver asper their schedule. We cannot direct or request them to deliver as per individual’s time slot.</li>
              </ul>  
              <br><br>
              <p>We welcome customers to place their orders who previously cancelled, rejected or refused at the time of delivery but with advance payment only.</p>
            <br><br><br>
            <h5>Delivery Charges</h5>
              <p>We offer FREE Delivery on invoice Rs 6000 and above. For lesser, flat Rs 150 will be charged.</p>
              <br><br><br>
             <h5>International Deliveries</h5>
              <p>Please email us at support@theskinfit.com</p>
            
            </div>
          </div>
        </div>
  </section>