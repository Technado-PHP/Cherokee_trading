 
  
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Contact Us</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Contact Us</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->
  
  <!-- CONTAIN START ptb-95-->

  <section class="pt-70 client-main align-center">
    <div class="container">
      <div class="contact-info">
       <div class="row">
        <div class="col-12">
          <div class="heading-part mb-30">
            <h2 class="heading"><span>We are devoted to providing exceptional customer service and the highest quality of beauty products.</span></h2>
          </div>
        </div>
      </div>
      <br>      <br>      <br>
        <div class="row m-0">
          <div class="col-md-4 p-0">
            <div class="contact-box">
              <div class="contact-icon contact-phone-icon"></div>
              <span><b>Tel</b></span>
              <p><?php echo !empty($this->phone)?$this->phone:''?></p>
            </div>
          </div>
          <div class="col-md-4 p-0">
            <div class="contact-box">
              <div class="contact-icon contact-mail-icon"></div>
              <span><b>Mail</b></span>
              <p><?php echo !empty($this->email_address)?$this->email_address:''?></p>
            </div>
          </div>
          <div class="col-md-4 p-0">
            <div class="contact-box">
              <div class="contact-icon contact-open-icon"></div>
              <span><b>Open</b></span>
              <p>Monday - Saturday — <span style="color:red">10am -7pm</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="heading-part mb-30">
            <h2 class="main_title  heading"><span>Leave a message!</span></h2>
          </div>
        </div>
      </div>
      <div class="main-form">
        <form action="<?php echo base_url('contact-us')?>" method="POST" name="contactform">
          <div class="row">
            <div class="col-md-4 mb-30">
              <input type="text" required placeholder="Name" value="<?php echo set_value('name');?>" name="name">  
              <?php echo form_error('name'); ?>
            </div>
            <div class="col-md-4 mb-30">
              <input type="email" placeholder="Email" value="<?php echo set_value('email');?>" name="email">  
              <?php echo form_error('email'); ?>
            </div>
            <div class="col-md-4 mb-30">
              <input type="text" required placeholder="Phone" value="<?php echo set_value('phone');?>" name="phone"> 
              <?php echo form_error('phone'); ?>
            </div>
            <div class="col-12 mb-30">
              <textarea required placeholder="Message" rows="3" cols="30" name="message"><?php echo set_value('message');?></textarea>  
              <?php echo form_error('message'); ?>
            </div>
            <div class="col-12">
              <div class="align-center">
                <button type="submit" name="submit" class="btn btn-color">Submit</button>
              </div>
            </div>
          </div>
        </form>
      </div>
      <br>      <br>      <br>
      <div class="row">
        <div class="col-12">
          <div class="heading-part mb-30">
            <h6 class="heading"><span>For business inquires and brand partnerships please email pr@theskinfit.com</span></h6>
          </div>
        </div>
      </div>
      <br>      <br>
      <div class="row">
        <div class="col-12">
          <div class="heading-part mb-30">
            <h6 class="heading"><span>For Blogger and endorsers please email blog@theskinfit.com</span></h6>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
  