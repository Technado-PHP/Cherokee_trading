
  <!-- Bread Crumb STRAT -->
  <div class="banner inner-banner1 ">
    <div class="container">
      <section class="banner-detail center-xs">
        <h1 class="banner-title">Product Comparison</h1>
        <div class="bread-crumb right-side float-none-xs">
          <ul>
            <li><a href="<?php echo base_url();?>">Home</a>/</li>
            <li><span>Product Comparison</span></li>
          </ul>
        </div>
      </section>
    </div>
  </div>
  <!-- Bread Crumb END -->
<?php if(empty($pro_one)):?>  
<style>
.cp1 {
    display: none;
}
</style>
<?php endif; ?> 
<?php if(empty($pro_two)):?>  
<style>
.cp2 {
    display: none;
}
</style>
<?php endif; ?>  
  <!-- CONTAIN START -->
  <section class="ptb-70">
    <div class="container">
      <div class="row">
        <div class="col-12 mb-xs-30">
          <?php if(!empty($pro_one) || !empty($pro_two)):?>          
          <div class="cart-item-table commun-table">
            <div class="table-responsive">
              <table class="compare-info">
                <tbody>
                  <tr>
                    <td></td>
                    <td class="image cp1"> 
                      <img src="<?php echo !empty($pro_one->product_image)?base_url('uploads/product/').$pro_one->product_image:'';?>" alt="Product Image" title="" class="img-thumbnail" /> 
                    </td>
                    <td class="image cp2"> 
                       <img src="<?php echo !empty($pro_two->product_image)?base_url('uploads/product/').$pro_two->product_image:'';?>" alt="Product Image" title="" class="img-thumbnail" /> 
                   </td>
                  </tr>
                  <tr>
                    <td>Name</td>
                    <td class="name cp1"> 
                        <?php echo $pro_one->product_name;?>    
                    </td>
                    <td class="name cp2"> 
                        <?php echo $pro_two->product_name;?>  
                    </td>
                  </tr>
                  <tr>
                      <td>Price</td>
                      <td class="name cp1">
                        <div class="price-box">
                            <?php if($pro_one->product_dis_price > 0):?>
                            <span class="price">
                                <?php echo $this->currency.$pro_one->product_dis_price;?>
                            </span> 
                            <del class="price old-price">
                                <?php echo $this->currency.$pro_one->product_reg_price;?>
                            </del>
                            <?php else:?>
                            <span class="price">
                                <?php echo $this->currency.$pro_one->product_reg_price;?>
                            </span>
                            <?php endif;?>
                        </div>
                      </td>
                      <td class="name cp2">                        
                        <div class="price-box">
                            <?php if($pro_two->product_dis_price > 0):?>
                            <span class="price">
                                <?php echo $this->currency.$pro_two->product_dis_price;?>
                            </span> 
                            <del class="price old-price">
                                <?php echo $this->currency.$pro_two->product_reg_price;?>
                            </del>
                            <?php else:?>
                            <span class="price">
                                <?php echo $this->currency.$pro_two->product_reg_price;?>
                            </span>
                            <?php endif;?>
                        </div>
                      </td>
                  </tr>
                  <tr>
                      <td>Sku</td>
                      <td class="cp1"><?php echo $pro_one->product_sku;?></td>
                      <td class="cp2"><?php echo $pro_two->product_sku;?></td>
                  </tr>
                  <tr>
                      <td>Brand</td>
                      <td class="cp1"><?php echo get_name_by_id('brand',$pro_one->brand_id);?></td>
                      <td class="cp2"><?php echo get_name_by_id('brand',$pro_two->brand_id);?></td>
                  </tr>
                  <tr>
                      <td>Availability</td>
                      <td class="availability cp1">
                        <?php $qty = check_inventory($pro_one->product_id);?>  
                        <?php echo $qty > 0?'In Stock': 'Out Of Stock'?>  
                       </td>
                      <td class="availability cp2">
                        <?php $qty = check_inventory($pro_two->product_id);?>  
                        <?php echo $qty > 0?'In Stock': 'Out Of Stock'?>  
                      </td>
                  </tr>
                  <tr>
                    <td>Rating</td>
                    <td class="rating cp1"> 
                      <?php $raring = round(get_rating($pro_one->product_id));?>                    
                      <?php for($i=1; $i <= $raring; $i++):?>  
                      <span class="fa fa-stack">
                        <i class="fa fa-star fa-stack-2x"></i>
                        <i class="fa fa-star-o fa-stack-2x"></i>
                      </span> 
                      <?php endfor;?>
                      <?php for($x=$i; $x <= 5; $x++):?>  
                      <span class="fa fa-stack">
                        <i class="fa fa-star-o fa-stack-2x"></i>
                      </span>
                      <?php endfor;?>
                    </td>
                    <td class="rating cp2"> 
                      <?php $raring = round(get_rating($pro_two->product_id));?>                    
                      <?php for($i=1; $i <= $raring; $i++):?>  
                      <span class="fa fa-stack">
                        <i class="fa fa-star fa-stack-2x"></i>
                        <i class="fa fa-star-o fa-stack-2x"></i>
                      </span> 
                      <?php endfor;?>
                      <?php for($x=$i; $x <= 5; $x++):?>  
                      <span class="fa fa-stack">
                        <i class="fa fa-star-o fa-stack-2x"></i>
                      </span>
                      <?php endfor;?>
                    </td>
                  </tr>
                  <tr>
                      <td>Summary</td>
                      <td class="description cp1"><?php echo $pro_one->product_short_desc;?></td>
                      <td class="description cp2"><?php echo $pro_two->product_short_desc;?></td>
                  </tr>
                </tbody>
                <tr>
                  <td></td>
                  <td class="cp1">
                    <button type="button" onclick="location.href = '<?php echo base_url()."product/".$pro_one->product_slug;?>';" class="btn btn-black"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
                    <button class="btn btn-color remove_compare" type="button" data-id="<?php echo $pro_one->product_id;?>" title="Remove">Remove</button>
                  </td>
                  <td class="cp2">
                    <button type="button" onclick="location.href = '<?php echo base_url()."product/".$pro_two->product_slug;?>';" class="btn btn-black"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
                    <button class="btn btn-color remove_compare" type="button" data-id="<?php echo $pro_two->product_id;?>" title="Remove">Remove</button>
                  </td>
                </tr>
              </table>
            </div>
          </div>
          <?php else:?>
          <h4>No product Found</h4>  
          <?php endif;?>
        </div>
      </div>
    </div>
  </section>
  <!-- CONTAINER END --> 
  