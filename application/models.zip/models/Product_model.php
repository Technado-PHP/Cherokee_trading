<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

	public function all_products($id)
	{
		$this->db->select('product','category_id','product_name','product_slug','product_image','product_reg_price','product_dis_price')
		->from("product")
		->where(array('product_status'=>'enable','category_id'=>$id));
		return $this->db->get()->result();
	}
	public function categories()
	{
		$this->db->select('*')
		->from('category')
		->where('category_status','enable');
		return $this->db->get()->result();
	}
}
