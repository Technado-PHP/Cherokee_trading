<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model {

	public function home_page()
	{
		$this->db->select('*')
		->from('home_page')
		->where('home_page_id',1);
		return $this->db->get()->row();
	}
	public function footer_top_data()
	{
		$this->db->select('home_page_heading_two,home_page_sub_heading')
		->from('home_page')
		->where('home_page_id',1);
		return $this->db->get()->row();
	}
	public function brands()
	{
		$this->db->select('brand_image')
		->from('brand')
		->where('brand_status','enable');
		return $this->db->get()->result();
	}
	public function testimonials()
	{
		$this->db->select('*')
		->from('testimonials')
		->where('testimonials_status','enable');
		return $this->db->get()->result();
	}
	public function blogs()
	{
		$this->db->select('*')
		->from('blog')
		->where('blog_status','enable')
		->order_by('blog_id','ASC')
		->limit(2);	
		return $this->db->get()->result();
	}
	public function home_slider()
	{
		$this->db->select('*')
		->from('slider')
		->where('slider_status','enable');
		return $this->db->get()->result();
	}
}